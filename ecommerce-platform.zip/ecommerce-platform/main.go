package main

import (
	"log"
	"net/http"
	"strings"

	"ecommerce-platform/config"
	"ecommerce-platform/handlers"
	"ecommerce-platform/middleware"
	"ecommerce-platform/supabase"
)

func main() {
	cfg := config.Load()

	if cfg.SupabaseURL == "" || cfg.SupabaseKey == "" {
		log.Println("⚠️  警告: SUPABASE_URL 和 SUPABASE_ANON_KEY 环境变量未设置")
		log.Println("   请在 .env 文件中设置或通过环境变量设置")
	}

	sb := supabase.NewClient(cfg.SupabaseURL, cfg.SupabaseKey, cfg.SupabaseServiceKey)

	// Init handlers
	authH := &handlers.AuthHandler{SB: sb}
	prodH := &handlers.ProductHandler{SB: sb}
	cartH := &handlers.CartHandler{SB: sb}
	orderH := &handlers.OrderHandler{SB: sb}
	adminH := &handlers.AdminHandler{SB: sb}

	// Auth middleware
	authMiddleware := middleware.Auth(sb)
	sellerMiddleware := middleware.RequireRole("seller", "admin")
	adminMiddleware := middleware.RequireRole("admin")

	mux := http.NewServeMux()

	// ==================== API Routes ====================

	// Auth (public)
	mux.HandleFunc("/api/auth/register", methodHandler("POST", authH.Register))
	mux.HandleFunc("/api/auth/login", methodHandler("POST", authH.Login))

	// Profile (auth required)
	mux.Handle("/api/auth/profile", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			authH.GetProfile(w, r)
		case "PUT", "PATCH":
			authH.UpdateProfile(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	})))

	// Addresses (auth required)
	mux.Handle("/api/addresses", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			authH.GetAddresses(w, r)
		case "POST":
			authH.CreateAddress(w, r)
		case "PUT", "PATCH":
			authH.UpdateAddress(w, r)
		case "DELETE":
			authH.DeleteAddress(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	})))

	// Products (public read)
	mux.HandleFunc("/api/products", func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			prodH.List(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	})
	mux.HandleFunc("/api/products/detail", func(w http.ResponseWriter, r *http.Request) {
		prodH.Get(w, r)
	})
	mux.HandleFunc("/api/categories", func(w http.ResponseWriter, r *http.Request) {
		prodH.GetCategories(w, r)
	})

	// Seller product management
	mux.Handle("/api/seller/products", authMiddleware(sellerMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			prodH.SellerProducts(w, r)
		case "POST":
			prodH.Create(w, r)
		case "PUT", "PATCH":
			prodH.Update(w, r)
		case "DELETE":
			prodH.Delete(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	}))))

	// Seller orders
	mux.Handle("/api/seller/orders", authMiddleware(sellerMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		orderH.SellerOrders(w, r)
	}))))
	mux.Handle("/api/seller/orders/ship", authMiddleware(sellerMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		orderH.ShipOrder(w, r)
	}))))

	// Cart (auth required)
	mux.Handle("/api/cart", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			cartH.GetCart(w, r)
		case "POST":
			cartH.AddToCart(w, r)
		case "PUT", "PATCH":
			cartH.UpdateCartItem(w, r)
		case "DELETE":
			cartH.RemoveCartItem(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	})))
	mux.Handle("/api/cart/clear", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		cartH.ClearCart(w, r)
	})))

	// Orders (auth required)
	mux.Handle("/api/orders", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			orderH.GetOrders(w, r)
		case "POST":
			orderH.CreateOrder(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	})))
	mux.Handle("/api/orders/detail", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		orderH.GetOrder(w, r)
	})))
	mux.Handle("/api/orders/pay", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		orderH.PayOrder(w, r)
	})))
	mux.Handle("/api/orders/cancel", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		orderH.CancelOrder(w, r)
	})))
	mux.Handle("/api/orders/confirm", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		orderH.ConfirmReceive(w, r)
	})))

	// Reviews
	mux.HandleFunc("/api/reviews", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "GET" {
			prodH.GetReviews(w, r)
			return
		}
		http.Error(w, "Method not allowed", 405)
	})
	mux.Handle("/api/reviews/create", authMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		prodH.CreateReview(w, r)
	})))

	// Admin routes
	mux.Handle("/api/admin/dashboard", authMiddleware(adminMiddleware(http.HandlerFunc(adminH.Dashboard))))
	mux.Handle("/api/admin/users", authMiddleware(adminMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			adminH.ListUsers(w, r)
		case "PUT", "PATCH":
			adminH.UpdateUserRole(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	}))))
	mux.Handle("/api/admin/products", authMiddleware(adminMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			adminH.ListProducts(w, r)
		case "PUT", "PATCH":
			adminH.ReviewProduct(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	}))))
	mux.Handle("/api/admin/orders", authMiddleware(adminMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case "GET":
			adminH.ListOrders(w, r)
		case "PUT", "PATCH":
			adminH.UpdateOrder(w, r)
		default:
			http.Error(w, "Method not allowed", 405)
		}
	}))))

	// ==================== Static files ====================
	// Serve SPA - pages
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		// API routes handled above
		if strings.HasPrefix(r.URL.Path, "/api/") {
			http.NotFound(w, r)
			return
		}
		// Static assets
		if strings.HasPrefix(r.URL.Path, "/static/") {
			http.StripPrefix("/static/", http.FileServer(http.Dir("static"))).ServeHTTP(w, r)
			return
		}
		// All page routes serve index.html (SPA)
		http.ServeFile(w, r, "static/pages/index.html")
	})

	// Static assets
	mux.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	// Apply global middleware
	handler := middleware.CORS(middleware.Logger(mux))

	log.Printf("🚀 电商平台启动成功 → http://localhost:%s", cfg.Port)
	log.Printf("📦 API 地址: http://localhost:%s/api", cfg.Port)
	log.Fatal(http.ListenAndServe(":"+cfg.Port, handler))
}

func methodHandler(method string, h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != method {
			http.Error(w, "Method not allowed", 405)
			return
		}
		h(w, r)
	}
}
