module ecommerce-platform

go 1.21
