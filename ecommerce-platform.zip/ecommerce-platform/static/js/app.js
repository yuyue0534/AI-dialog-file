/* ============================================================
   E-Commerce SPA — Core Application
   ============================================================ */

// ==================== Config ====================
const CONFIG = {
  API_BASE: '/api',
};

// ==================== API Client ====================
const API = {
  token: localStorage.getItem('token') || '',
  user: JSON.parse(localStorage.getItem('user') || 'null'),

  setAuth(token, user) {
    this.token = token;
    this.user = user;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
  },

  clearAuth() {
    this.token = '';
    this.user = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },

  isLoggedIn() {
    return !!this.token && !!this.user;
  },

  async request(path, options = {}) {
    const url = CONFIG.API_BASE + path;
    const headers = { 'Content-Type': 'application/json' };
    if (this.token) headers['Authorization'] = 'Bearer ' + this.token;

    try {
      const resp = await fetch(url, { ...options, headers: { ...headers, ...options.headers } });
      const data = await resp.json();
      if (resp.status === 401) {
        this.clearAuth();
        Toast.error('登录已过期，请重新登录');
        Router.go('/login');
        return null;
      }
      return data;
    } catch (e) {
      console.error('API Error:', e);
      Toast.error('网络请求失败');
      return null;
    }
  },

  get(path) { return this.request(path); },
  post(path, body) { return this.request(path, { method: 'POST', body: JSON.stringify(body) }); },
  put(path, body) { return this.request(path, { method: 'PUT', body: JSON.stringify(body) }); },
  patch(path, body) { return this.request(path, { method: 'PATCH', body: JSON.stringify(body) }); },
  del(path) { return this.request(path, { method: 'DELETE' }); },
};

// ==================== Toast ====================
const Toast = {
  container: null,
  init() {
    this.container = document.createElement('div');
    this.container.className = 'toast-container';
    document.body.appendChild(this.container);
  },
  show(msg, type = 'success') {
    if (!this.container) this.init();
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    const icons = { success: '✓', error: '✕', warning: '⚠' };
    t.innerHTML = `<span>${icons[type] || '●'}</span><span>${msg}</span>`;
    this.container.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, 3000);
  },
  success(msg) { this.show(msg, 'success'); },
  error(msg) { this.show(msg, 'error'); },
  warning(msg) { this.show(msg, 'warning'); },
};

// ==================== Router ====================
const Router = {
  routes: {},
  currentRoute: null,

  register(path, handler) { this.routes[path] = handler; },

  go(path) {
    history.pushState(null, '', path);
    this.resolve();
  },

  resolve() {
    const path = location.pathname;
    let handler = null;
    let params = {};

    // Exact match
    if (this.routes[path]) {
      handler = this.routes[path];
    } else {
      // Try pattern matching
      for (const [route, h] of Object.entries(this.routes)) {
        if (route.includes(':')) {
          const routeParts = route.split('/');
          const pathParts = path.split('/');
          if (routeParts.length === pathParts.length) {
            let match = true;
            for (let i = 0; i < routeParts.length; i++) {
              if (routeParts[i].startsWith(':')) {
                params[routeParts[i].slice(1)] = pathParts[i];
              } else if (routeParts[i] !== pathParts[i]) {
                match = false;
                break;
              }
            }
            if (match) { handler = h; break; }
          }
        }
      }
    }

    if (!handler) handler = this.routes['/'];
    if (handler) {
      this.currentRoute = path;
      handler(params);
    }
  },

  init() {
    window.addEventListener('popstate', () => this.resolve());
    document.addEventListener('click', e => {
      const a = e.target.closest('a[data-link]');
      if (a) {
        e.preventDefault();
        this.go(a.getAttribute('href'));
      }
    });
    this.resolve();
  },
};

// ==================== Utils ====================
const Utils = {
  formatPrice(price) {
    return '¥' + parseFloat(price || 0).toFixed(2);
  },

  formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('zh-CN') + ' ' + d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  },

  statusText(status) {
    const map = {
      pending_payment: '待支付', pending_ship: '待发货', shipped: '已发货',
      completed: '已完成', cancelled: '已取消', refunding: '退款中',
      pending: '待审核', approved: '已通过', rejected: '已拒绝', offline: '已下架',
    };
    return map[status] || status;
  },

  stars(rating, size = '1rem') {
    let html = '<span class="stars">';
    for (let i = 1; i <= 5; i++) {
      html += `<span class="star ${i <= rating ? 'filled' : ''}" style="font-size:${size}">★</span>`;
    }
    return html + '</span>';
  },

  getFirstImage(images) {
    try {
      if (typeof images === 'string') {
        const arr = JSON.parse(images);
        if (arr.length > 0) return arr[0];
      }
    } catch (e) {}
    return '';
  },

  placeholder(text = '📦') {
    return `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:var(--smoke);font-size:2rem;">${text}</div>`;
  },

  productImage(images) {
    const src = this.getFirstImage(images);
    if (src) return `<img src="${src}" alt="" style="width:100%;height:100%;object-fit:cover;">`;
    return this.placeholder();
  },
};

// ==================== App Shell ====================
const App = {
  root: null,

  init() {
    this.root = document.getElementById('app');
    Toast.init();
    this.registerRoutes();
    Router.init();
  },

  registerRoutes() {
    Router.register('/', () => this.renderPage(Pages.Home));
    Router.register('/login', () => this.renderAuth(Pages.Login));
    Router.register('/register', () => this.renderAuth(Pages.Register));
    Router.register('/products', () => this.renderPage(Pages.Products));
    Router.register('/product/:id', (p) => this.renderPage(() => Pages.ProductDetail(p.id)));
    Router.register('/cart', () => this.renderPage(Pages.Cart));
    Router.register('/checkout', () => this.renderPage(Pages.Checkout));
    Router.register('/orders', () => this.renderPage(Pages.Orders));
    Router.register('/profile', () => this.renderPage(Pages.Profile));
    Router.register('/seller', () => this.renderPage(Pages.SellerDashboard));
    Router.register('/admin', () => this.renderPage(Pages.AdminDashboard));
  },

  renderPage(pageFn) {
    this.root.innerHTML = this.navbarHTML() + '<div class="page"><div class="container" id="page-content"></div></div>';
    this.bindNavbar();
    pageFn();
  },

  renderAuth(pageFn) {
    this.root.innerHTML = '<div id="page-content"></div>';
    pageFn();
  },

  navbarHTML() {
    const user = API.user;
    const isLoggedIn = API.isLoggedIn();
    return `
      <nav class="navbar">
        <div class="navbar-inner">
          <a href="/" data-link class="navbar-brand">
            <span class="brand-icon">🛍</span>
            <span>朱雀商城</span>
          </a>
          <div class="navbar-search">
            <span class="search-icon">🔍</span>
            <input type="text" placeholder="搜索商品..." id="nav-search" onkeypress="if(event.key==='Enter')Router.go('/products?search='+this.value)">
          </div>
          <div class="navbar-actions">
            <a href="/products" data-link class="nav-btn">🏪 商品</a>
            ${isLoggedIn ? `
              <a href="/cart" data-link class="nav-btn" id="nav-cart-btn">🛒 购物车<span class="badge hidden" id="cart-badge">0</span></a>
              <a href="/orders" data-link class="nav-btn">📋 订单</a>
              ${user?.role === 'seller' || user?.role === 'admin' ? `<a href="/seller" data-link class="nav-btn">📊 商家</a>` : ''}
              ${user?.role === 'admin' ? `<a href="/admin" data-link class="nav-btn">⚙️ 管理</a>` : ''}
              <a href="/profile" data-link class="nav-btn">👤 ${user?.name || '我的'}</a>
              <button class="nav-btn" onclick="API.clearAuth();Router.go('/login')">退出</button>
            ` : `
              <a href="/login" data-link class="nav-btn">登录</a>
              <a href="/register" data-link class="btn btn-primary btn-sm">注册</a>
            `}
          </div>
        </div>
      </nav>`;
  },

  async bindNavbar() {
    if (API.isLoggedIn()) {
      const data = await API.get('/cart');
      if (data?.success && data.data) {
        const count = data.data.length;
        const badge = document.getElementById('cart-badge');
        if (badge) {
          badge.textContent = count;
          badge.classList.toggle('hidden', count === 0);
        }
      }
    }
  },
};

// ==================== Pages ====================
const Pages = {

  // ===== HOME =====
  async Home() {
    const content = document.getElementById('page-content');
    content.innerHTML = `
      <div class="hero" style="margin: -24px -20px 32px; border-radius: 0;">
        <div class="hero-content">
          <h1>发现好物，尽在朱雀</h1>
          <p>汇聚全球优质商品，为您提供卓越的购物体验</p>
          <div class="hero-actions">
            <a href="/products" data-link class="btn btn-primary btn-lg">开始购物</a>
            ${!API.isLoggedIn() ? '<a href="/register" data-link class="btn btn-gold btn-lg">立即注册</a>' : ''}
          </div>
        </div>
      </div>
      <div id="categories-bar" class="category-bar"></div>
      <h2 style="margin: 20px 0 16px;">热门推荐</h2>
      <div id="home-products" class="product-grid"><div class="loading"><div class="spinner"></div></div></div>
    `;

    // Load categories
    const catData = await API.get('/categories');
    if (catData?.success) {
      const bar = document.getElementById('categories-bar');
      bar.innerHTML = `<span class="category-chip active" onclick="Pages.filterCategory('')">全部</span>` +
        catData.data.map(c => `<span class="category-chip" onclick="Pages.filterCategory('${c.name}')">${c.icon} ${c.name}</span>`).join('');
    }

    // Load products
    const prodData = await API.get('/products?limit=20');
    Pages.renderProductGrid('home-products', prodData);
  },

  filterCategory(cat) {
    document.querySelectorAll('.category-chip').forEach(c => c.classList.remove('active'));
    event.target.classList.add('active');
    const container = document.getElementById('home-products');
    container.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
    API.get(`/products?limit=20${cat ? '&category=' + encodeURIComponent(cat) : ''}`).then(data => {
      Pages.renderProductGrid('home-products', data);
    });
  },

  renderProductGrid(containerId, data) {
    const container = document.getElementById(containerId);
    if (!data?.success || !data.data?.length) {
      container.innerHTML = '<div class="empty-state"><div class="icon">📦</div><h3>暂无商品</h3><p>换个关键词试试</p></div>';
      return;
    }
    container.innerHTML = data.data.map(p => `
      <div class="product-card" onclick="Router.go('/product/${p.id}')">
        <div class="product-card-img">${Utils.productImage(p.images)}</div>
        <div class="product-card-body">
          <div class="product-card-title">${p.name}</div>
          <div class="product-card-price">
            <span class="price-current"><span class="yen">¥</span>${parseFloat(p.price).toFixed(2)}</span>
            ${p.orig_price > p.price ? `<span class="price-original">¥${parseFloat(p.orig_price).toFixed(2)}</span>` : ''}
          </div>
          <div class="product-card-meta">
            <span>销量 ${p.sales || 0}</span>
            <span>${Utils.stars(Math.round(p.rating || 0), '0.75rem')}</span>
          </div>
        </div>
      </div>
    `).join('');
  },

  // ===== PRODUCTS LIST =====
  async Products() {
    const content = document.getElementById('page-content');
    const params = new URLSearchParams(location.search);
    const search = params.get('search') || '';
    const category = params.get('category') || '';

    content.innerHTML = `
      <div class="page-header flex justify-between items-center">
        <h1 class="page-title">商品列表</h1>
        <div class="flex gap-sm">
          <input type="text" class="form-input" style="width:240px" placeholder="搜索商品..." id="search-input" value="${search}">
          <select class="form-input" style="width:140px" id="sort-select">
            <option value="">默认排序</option>
            <option value="price_asc">价格升序</option>
            <option value="price_desc">价格降序</option>
            <option value="sales">按销量</option>
            <option value="rating">按评分</option>
          </select>
          <button class="btn btn-primary" onclick="Pages.searchProducts()">搜索</button>
        </div>
      </div>
      <div id="product-list" class="product-grid"><div class="loading"><div class="spinner"></div></div></div>
    `;

    let url = `/products?limit=40`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (category) url += `&category=${encodeURIComponent(category)}`;
    const data = await API.get(url);
    Pages.renderProductGrid('product-list', data);
  },

  searchProducts() {
    const search = document.getElementById('search-input').value;
    const sort = document.getElementById('sort-select').value;
    let url = '/products?';
    if (search) url += `search=${encodeURIComponent(search)}&`;
    if (sort) url += `sort=${sort}&`;
    Router.go(url);
  },

  // ===== PRODUCT DETAIL =====
  async ProductDetail(id) {
    const content = document.getElementById('page-content');
    content.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

    const data = await API.get(`/products/detail?id=${id}`);
    if (!data?.success) {
      content.innerHTML = '<div class="empty-state"><div class="icon">😿</div><h3>商品不存在</h3></div>';
      return;
    }

    const p = data.data;
    let images = [];
    try { images = JSON.parse(p.images || '[]'); } catch(e) {}
    const mainImg = images.length > 0 ? `<img src="${images[0]}" alt="${p.name}">` : Utils.placeholder('🖼️');

    content.innerHTML = `
      <div class="product-detail">
        <div class="product-gallery">${mainImg}</div>
        <div class="product-info">
          <h1 class="product-title">${p.name}</h1>
          <div class="product-price-row">
            <span class="price-big"><span class="yen">¥</span>${parseFloat(p.price).toFixed(2)}</span>
            ${p.orig_price > p.price ? `<span class="price-original" style="margin-left:12px;font-size:1rem;">¥${parseFloat(p.orig_price).toFixed(2)}</span>` : ''}
          </div>
          <div class="product-meta-row">
            <span>📦 库存: ${p.stock}</span>
            <span>🏷️ ${p.category}</span>
            <span>📈 销量: ${p.sales || 0}</span>
            <span>${Utils.stars(Math.round(p.rating || 0))}</span>
          </div>
          ${p.brand ? `<p style="color:var(--ink-muted);font-size:0.9rem;">品牌: ${p.brand}</p>` : ''}
          ${p.seller_name ? `<p style="color:var(--ink-muted);font-size:0.9rem;margin-top:4px;">商家: ${p.seller_name}</p>` : ''}
          <div class="quantity-control">
            <button onclick="Pages.changeQty(-1)">−</button>
            <input type="number" id="buy-qty" value="1" min="1" max="${p.stock}">
            <button onclick="Pages.changeQty(1)">+</button>
            <span style="margin-left:12px;color:var(--ink-muted);font-size:0.85rem;">件</span>
          </div>
          <div class="product-actions">
            <button class="btn btn-primary btn-lg" onclick="Pages.addToCart('${p.id}')" ${p.stock <= 0 ? 'disabled' : ''}>
              ${p.stock > 0 ? '🛒 加入购物车' : '暂时缺货'}
            </button>
            <button class="btn btn-gold btn-lg" onclick="Pages.buyNow('${p.id}')" ${p.stock <= 0 ? 'disabled' : ''}>
              ⚡ 立即购买
            </button>
          </div>
          <div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--border);">
            <h3>商品详情</h3>
            <p style="margin-top:10px;color:var(--ink-light);font-size:0.9rem;line-height:1.8;">${p.description || '暂无详情'}</p>
          </div>
        </div>
      </div>
      <div style="margin-top:32px;">
        <h2 style="margin-bottom:16px;">商品评价</h2>
        <div id="reviews-list"><div class="loading"><div class="spinner"></div></div></div>
      </div>
    `;

    // Load reviews
    const reviews = await API.get(`/reviews?product_id=${id}`);
    const reviewsEl = document.getElementById('reviews-list');
    if (reviews?.success && reviews.data?.length) {
      reviewsEl.innerHTML = reviews.data.map(rv => `
        <div class="review-card">
          <div class="review-header">
            <div class="review-avatar">${(rv.user_name || '匿')[0]}</div>
            <div>
              <div style="font-weight:500;font-size:0.9rem;">${rv.user_name || '匿名'}</div>
              <div style="font-size:0.75rem;color:var(--ink-muted);">${Utils.formatDate(rv.created_at)}</div>
            </div>
            <div style="margin-left:auto;">${Utils.stars(rv.rating)}</div>
          </div>
          <div class="review-content">${rv.content}</div>
          ${rv.reply ? `<div class="review-reply"><span class="label">商家回复: </span>${rv.reply}</div>` : ''}
        </div>
      `).join('');
    } else {
      reviewsEl.innerHTML = '<div class="empty-state" style="padding:30px;"><p>暂无评价</p></div>';
    }
  },

  changeQty(delta) {
    const input = document.getElementById('buy-qty');
    let v = parseInt(input.value) + delta;
    if (v < 1) v = 1;
    if (v > parseInt(input.max)) v = parseInt(input.max);
    input.value = v;
  },

  async addToCart(productId) {
    if (!API.isLoggedIn()) { Router.go('/login'); return; }
    const qty = parseInt(document.getElementById('buy-qty')?.value || 1);
    const data = await API.post('/cart', { product_id: productId, quantity: qty });
    if (data?.success) {
      Toast.success('已加入购物车');
      App.bindNavbar();
    } else {
      Toast.error(data?.message || '操作失败');
    }
  },

  async buyNow(productId) {
    if (!API.isLoggedIn()) { Router.go('/login'); return; }
    const qty = parseInt(document.getElementById('buy-qty')?.value || 1);
    const data = await API.post('/cart', { product_id: productId, quantity: qty });
    if (data?.success) {
      Router.go('/checkout');
    } else {
      Toast.error(data?.message || '操作失败');
    }
  },

  // ===== CART =====
  async Cart() {
    if (!API.isLoggedIn()) { Router.go('/login'); return; }
    const content = document.getElementById('page-content');
    content.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

    const data = await API.get('/cart');
    if (!data?.success) { content.innerHTML = '<p>加载失败</p>'; return; }

    const items = data.data || [];
    if (!items.length) {
      content.innerHTML = `
        <div class="empty-state">
          <div class="icon">🛒</div>
          <h3>购物车空空如也</h3>
          <p>去挑选心仪的商品吧</p>
          <a href="/products" data-link class="btn btn-primary mt-2">去逛逛</a>
        </div>`;
      return;
    }

    const renderCart = () => {
      const selected = items.filter(i => i.selected !== false);
      const total = selected.reduce((s, i) => s + (i.price || 0) * (i.quantity || 0), 0);
      const count = selected.reduce((s, i) => s + (i.quantity || 0), 0);

      content.innerHTML = `
        <h1 class="page-title mb-2">购物车 (${items.length})</h1>
        <div class="cart-layout">
          <div id="cart-items">
            ${items.map((item, idx) => `
              <div class="cart-item" data-idx="${idx}">
                <div class="cart-item-check">
                  <input type="checkbox" ${item.selected !== false ? 'checked' : ''}
                    onchange="Pages.toggleCartItem(${idx}, this.checked)">
                </div>
                <div class="cart-item-img">${item.product_image ? `<img src="${item.product_image}" style="width:90px;height:90px;object-fit:cover;border-radius:6px;">` : '📦'}</div>
                <div class="cart-item-info">
                  <div class="name">${item.product_name || '商品'}</div>
                  <div class="price">${Utils.formatPrice(item.price)}</div>
                </div>
                <div class="cart-item-actions">
                  <div class="quantity-control">
                    <button onclick="Pages.updateCartQty(${idx}, -1)">−</button>
                    <input type="number" value="${item.quantity}" min="1" readonly style="width:44px;height:30px;">
                    <button onclick="Pages.updateCartQty(${idx}, 1)">+</button>
                  </div>
                  <button class="cart-item-remove" onclick="Pages.removeCartItem(${idx})">删除</button>
                </div>
              </div>
            `).join('')}
          </div>
          <div class="cart-summary">
            <h3>订单摘要</h3>
            <div class="cart-summary-row"><span>已选商品</span><span>${count} 件</span></div>
            <div class="cart-summary-row"><span>运费</span><span style="color:var(--success)">免运费</span></div>
            <div class="cart-summary-total">
              <span>合计</span>
              <span class="total-price">${Utils.formatPrice(total)}</span>
            </div>
            <button class="btn btn-primary btn-block btn-lg mt-2" onclick="Router.go('/checkout')" ${!selected.length ? 'disabled' : ''}>
              去结算 (${count})
            </button>
          </div>
        </div>
      `;
    };

    // Store items for manipulation
    Pages._cartItems = items;
    renderCart();
    Pages._renderCart = renderCart;
  },

  _cartItems: [],
  _renderCart: null,

  async toggleCartItem(idx, checked) {
    const item = Pages._cartItems[idx];
    await API.put(`/cart?id=${item.id}`, { selected: checked });
    item.selected = checked;
    if (Pages._renderCart) Pages._renderCart();
  },

  async updateCartQty(idx, delta) {
    const item = Pages._cartItems[idx];
    const newQty = item.quantity + delta;
    if (newQty < 1) return;
    await API.put(`/cart?id=${item.id}`, { quantity: newQty });
    item.quantity = newQty;
    if (Pages._renderCart) Pages._renderCart();
  },

  async removeCartItem(idx) {
    const item = Pages._cartItems[idx];
    await API.del(`/cart?id=${item.id}`);
    Pages._cartItems.splice(idx, 1);
    Toast.success('已移除');
    if (Pages._cartItems.length === 0) {
      Pages.Cart();
    } else if (Pages._renderCart) {
      Pages._renderCart();
    }
    App.bindNavbar();
  },

  // ===== CHECKOUT =====
  async Checkout() {
    if (!API.isLoggedIn()) { Router.go('/login'); return; }
    const content = document.getElementById('page-content');
    content.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

    const [cartData, addrData] = await Promise.all([
      API.get('/cart'),
      API.get('/addresses'),
    ]);

    const items = (cartData?.data || []).filter(i => i.selected !== false);
    const addresses = addrData?.data || [];

    if (!items.length) {
      content.innerHTML = '<div class="empty-state"><div class="icon">🛒</div><h3>没有待结算的商品</h3></div>';
      return;
    }

    const total = items.reduce((s, i) => s + (i.price || 0) * (i.quantity || 0), 0);

    content.innerHTML = `
      <h1 class="page-title mb-2">确认订单</h1>
      <div class="cart-layout">
        <div>
          <div class="card mb-2">
            <div class="card-body">
              <h3 style="margin-bottom:12px;">收货地址</h3>
              ${addresses.length ? `
                <select class="form-input" id="checkout-addr">
                  ${addresses.map(a => `<option value="${a.id}" ${a.is_default ? 'selected' : ''}>${a.name} ${a.phone} - ${a.province}${a.city}${a.district}${a.detail}</option>`).join('')}
                </select>
              ` : `
                <p style="color:var(--ink-muted);margin-bottom:12px;">您还没有收货地址</p>
              `}
              <button class="btn btn-secondary btn-sm mt-1" onclick="Pages.showAddressModal()">+ 新增地址</button>
            </div>
          </div>
          <div class="card">
            <div class="card-body">
              <h3 style="margin-bottom:12px;">商品清单</h3>
              ${items.map(i => `
                <div class="order-item" style="padding:10px 0;">
                  <div class="order-item-img">${i.product_image ? `<img src="${i.product_image}" style="width:64px;height:64px;object-fit:cover;border-radius:6px;">` : '📦'}</div>
                  <div class="order-item-info">
                    <div class="name">${i.product_name}</div>
                    <div class="qty">x${i.quantity}</div>
                  </div>
                  <div class="order-item-price">${Utils.formatPrice(i.price * i.quantity)}</div>
                </div>
              `).join('')}
            </div>
          </div>
          <div class="card mt-2">
            <div class="card-body">
              <div class="form-group">
                <label>支付方式</label>
                <select class="form-input" id="payment-method">
                  <option value="alipay">支付宝</option>
                  <option value="wechat">微信支付</option>
                  <option value="card">银行卡</option>
                </select>
              </div>
              <div class="form-group">
                <label>订单备注</label>
                <input type="text" class="form-input" id="order-remark" placeholder="选填">
              </div>
            </div>
          </div>
        </div>
        <div class="cart-summary">
          <h3>订单金额</h3>
          <div class="cart-summary-row"><span>商品总额</span><span>${Utils.formatPrice(total)}</span></div>
          <div class="cart-summary-row"><span>运费</span><span style="color:var(--success)">免运费</span></div>
          <div class="cart-summary-total">
            <span>应付</span>
            <span class="total-price">${Utils.formatPrice(total)}</span>
          </div>
          <button class="btn btn-primary btn-block btn-lg mt-2" onclick="Pages.placeOrder()">提交订单</button>
        </div>
      </div>
    `;
  },

  showAddressModal() {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal">
        <div class="modal-header">
          <h3>新增收货地址</h3>
          <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label>收货人</label><input class="form-input" id="addr-name" placeholder="姓名"></div>
          <div class="form-group"><label>手机号</label><input class="form-input" id="addr-phone" placeholder="手机号码"></div>
          <div class="form-group"><label>省份</label><input class="form-input" id="addr-province" placeholder="省"></div>
          <div class="form-group"><label>城市</label><input class="form-input" id="addr-city" placeholder="市"></div>
          <div class="form-group"><label>区/县</label><input class="form-input" id="addr-district" placeholder="区/县"></div>
          <div class="form-group"><label>详细地址</label><input class="form-input" id="addr-detail" placeholder="街道、门牌号等"></div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">取消</button>
          <button class="btn btn-primary" onclick="Pages.saveAddress()">保存</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  },

  async saveAddress() {
    const addr = {
      name: document.getElementById('addr-name').value,
      phone: document.getElementById('addr-phone').value,
      province: document.getElementById('addr-province').value,
      city: document.getElementById('addr-city').value,
      district: document.getElementById('addr-district').value,
      detail: document.getElementById('addr-detail').value,
      is_default: false,
    };
    if (!addr.name || !addr.phone || !addr.detail) {
      Toast.error('请填写完整信息');
      return;
    }
    const data = await API.post('/addresses', addr);
    if (data?.success) {
      Toast.success('地址已保存');
      document.querySelector('.modal-overlay')?.remove();
      Pages.Checkout();
    } else {
      Toast.error(data?.message || '保存失败');
    }
  },

  async placeOrder() {
    const addrEl = document.getElementById('checkout-addr');
    if (!addrEl || !addrEl.value) {
      Toast.error('请选择收货地址');
      return;
    }

    const data = await API.post('/orders', {
      address_id: addrEl.value,
      payment_method: document.getElementById('payment-method').value,
      remark: document.getElementById('order-remark').value,
    });

    if (data?.success) {
      Toast.success('订单创建成功！');
      // Simulate payment
      if (confirm('是否立即支付 ' + Utils.formatPrice(data.data.total) + '？')) {
        const payData = await API.post(`/orders/pay?id=${data.data.order_id}`, {
          payment_method: document.getElementById('payment-method').value,
        });
        if (payData?.success) {
          Toast.success('支付成功！');
        }
      }
      Router.go('/orders');
    } else {
      Toast.error(data?.message || '下单失败');
    }
  },

  // ===== ORDERS =====
  async Orders() {
    if (!API.isLoggedIn()) { Router.go('/login'); return; }
    const content = document.getElementById('page-content');

    const statuses = [
      { key: '', label: '全部' },
      { key: 'pending_payment', label: '待支付' },
      { key: 'pending_ship', label: '待发货' },
      { key: 'shipped', label: '已发货' },
      { key: 'completed', label: '已完成' },
    ];

    content.innerHTML = `
      <h1 class="page-title mb-2">我的订单</h1>
      <div class="tabs" id="order-tabs">
        ${statuses.map((s, i) => `<button class="tab ${i === 0 ? 'active' : ''}" onclick="Pages.loadOrders('${s.key}', this)">${s.label}</button>`).join('')}
      </div>
      <div id="orders-list"><div class="loading"><div class="spinner"></div></div></div>
    `;

    Pages.loadOrders('');
  },

  async loadOrders(status, tabEl) {
    if (tabEl) {
      document.querySelectorAll('#order-tabs .tab').forEach(t => t.classList.remove('active'));
      tabEl.classList.add('active');
    }

    const container = document.getElementById('orders-list');
    container.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

    const url = `/orders?limit=20${status ? '&status=' + status : ''}`;
    const data = await API.get(url);

    if (!data?.success || !data.data?.length) {
      container.innerHTML = '<div class="empty-state"><div class="icon">📋</div><h3>暂无订单</h3></div>';
      return;
    }

    container.innerHTML = data.data.map(order => `
      <div class="order-card">
        <div class="order-card-header">
          <div>
            <span class="order-no">${order.order_no}</span>
            <span style="margin-left:12px;color:var(--ink-muted);font-size:0.8rem;">${Utils.formatDate(order.created_at)}</span>
          </div>
          <span class="order-status status-${order.status}">${Utils.statusText(order.status)}</span>
        </div>
        ${(order.items || []).map(item => `
          <div class="order-item">
            <div class="order-item-img">${item.product_image ? `<img src="${item.product_image}" style="width:64px;height:64px;object-fit:cover;border-radius:6px;">` : '📦'}</div>
            <div class="order-item-info">
              <div class="name">${item.product_name}</div>
              <div class="qty">x${item.quantity}</div>
            </div>
            <div class="order-item-price">${Utils.formatPrice(item.price * item.quantity)}</div>
          </div>
        `).join('')}
        <div class="order-card-footer">
          <div class="order-total">合计: <span>${Utils.formatPrice(order.total_amount)}</span></div>
          <div class="order-actions">
            ${order.status === 'pending_payment' ? `
              <button class="btn btn-primary btn-sm" onclick="Pages.payOrder('${order.id}')">去支付</button>
              <button class="btn btn-secondary btn-sm" onclick="Pages.cancelOrder('${order.id}')">取消</button>
            ` : ''}
            ${order.status === 'shipped' ? `
              <button class="btn btn-success btn-sm" onclick="Pages.confirmOrder('${order.id}')">确认收货</button>
            ` : ''}
            ${order.status === 'completed' ? `
              <button class="btn btn-gold btn-sm" onclick="Pages.showReviewModal('${order.id}', '${(order.items||[])[0]?.product_id || ''}')">评价</button>
            ` : ''}
            ${order.tracking_no ? `<span style="font-size:0.8rem;color:var(--ink-muted);">物流: ${order.tracking_no}</span>` : ''}
          </div>
        </div>
      </div>
    `).join('');
  },

  async payOrder(orderId) {
    if (confirm('确认支付此订单？')) {
      const data = await API.post(`/orders/pay?id=${orderId}`, { payment_method: 'alipay' });
      if (data?.success) { Toast.success('支付成功'); Pages.loadOrders(''); }
      else Toast.error(data?.message || '支付失败');
    }
  },

  async cancelOrder(orderId) {
    if (confirm('确认取消此订单？')) {
      const data = await API.post(`/orders/cancel?id=${orderId}`, {});
      if (data?.success) { Toast.success('订单已取消'); Pages.loadOrders(''); }
      else Toast.error(data?.message || '操作失败');
    }
  },

  async confirmOrder(orderId) {
    if (confirm('确认收货？')) {
      const data = await API.post(`/orders/confirm?id=${orderId}`, {});
      if (data?.success) { Toast.success('已确认收货'); Pages.loadOrders(''); }
      else Toast.error(data?.message || '操作失败');
    }
  },

  showReviewModal(orderId, productId) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal">
        <div class="modal-header">
          <h3>商品评价</h3>
          <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>评分</label>
            <div id="review-stars" style="font-size:1.5rem;cursor:pointer;">
              ${[1,2,3,4,5].map(i => `<span class="star" data-v="${i}" onclick="Pages.setReviewRating(${i})">★</span>`).join('')}
            </div>
          </div>
          <div class="form-group">
            <label>评价内容</label>
            <textarea class="form-input" id="review-content" rows="4" placeholder="分享您的使用体验..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">取消</button>
          <button class="btn btn-primary" onclick="Pages.submitReview('${orderId}','${productId}')">提交评价</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    Pages._reviewRating = 5;
    Pages.setReviewRating(5);
  },

  _reviewRating: 5,
  setReviewRating(n) {
    Pages._reviewRating = n;
    document.querySelectorAll('#review-stars .star').forEach(s => {
      s.classList.toggle('filled', parseInt(s.dataset.v) <= n);
    });
  },

  async submitReview(orderId, productId) {
    const data = await API.post('/reviews/create', {
      order_id: orderId,
      product_id: productId,
      rating: Pages._reviewRating,
      content: document.getElementById('review-content').value,
    });
    if (data?.success) {
      Toast.success('评价成功');
      document.querySelector('.modal-overlay')?.remove();
    } else {
      Toast.error(data?.message || '评价失败');
    }
  },

  // ===== PROFILE =====
  async Profile() {
    if (!API.isLoggedIn()) { Router.go('/login'); return; }
    const content = document.getElementById('page-content');
    content.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

    const [profileData, addrData] = await Promise.all([
      API.get('/auth/profile'),
      API.get('/addresses'),
    ]);

    const user = profileData?.data || API.user;
    const addresses = addrData?.data || [];

    content.innerHTML = `
      <h1 class="page-title mb-2">个人中心</h1>
      <div class="dashboard-layout">
        <div class="sidebar">
          <nav class="sidebar-nav">
            <a href="/profile" data-link class="active">👤 个人信息</a>
            <a href="/orders" data-link>📋 我的订单</a>
            <a href="/cart" data-link>🛒 购物车</a>
            ${user.role === 'seller' || user.role === 'admin' ? '<a href="/seller" data-link>📊 商家中心</a>' : ''}
            ${user.role === 'admin' ? '<a href="/admin" data-link>⚙️ 管理后台</a>' : ''}
          </nav>
        </div>
        <div>
          <div class="card mb-2">
            <div class="card-body">
              <h3 style="margin-bottom:16px;">基本信息</h3>
              <div class="form-group"><label>姓名</label><input class="form-input" id="profile-name" value="${user.name || ''}"></div>
              <div class="form-group"><label>邮箱</label><input class="form-input" value="${user.email || ''}" disabled></div>
              <div class="form-group"><label>手机号</label><input class="form-input" id="profile-phone" value="${user.phone || ''}"></div>
              <div class="form-group"><label>角色</label><input class="form-input" value="${Utils.statusText(user.role) || user.role}" disabled></div>
              <button class="btn btn-primary" onclick="Pages.saveProfile()">保存修改</button>
            </div>
          </div>
          <div class="card">
            <div class="card-body">
              <div class="flex justify-between items-center" style="margin-bottom:16px;">
                <h3>收货地址</h3>
                <button class="btn btn-secondary btn-sm" onclick="Pages.showAddressModal()">+ 新增</button>
              </div>
              ${addresses.length ? addresses.map(a => `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--border);">
                  <div>
                    <div style="font-weight:500;">${a.name} <span style="color:var(--ink-muted);font-size:0.85rem;">${a.phone}</span></div>
                    <div style="font-size:0.85rem;color:var(--ink-light);margin-top:2px;">${a.province}${a.city}${a.district}${a.detail}</div>
                  </div>
                  <button class="btn btn-secondary btn-sm" onclick="Pages.deleteAddress('${a.id}')">删除</button>
                </div>
              `).join('') : '<p style="color:var(--ink-muted);">暂无收货地址</p>'}
            </div>
          </div>
        </div>
      </div>
    `;
  },

  async saveProfile() {
    const data = await API.put('/auth/profile', {
      name: document.getElementById('profile-name').value,
      phone: document.getElementById('profile-phone').value,
    });
    if (data?.success) {
      Toast.success('保存成功');
      if (data.data) {
        API.user = { ...API.user, ...data.data };
        localStorage.setItem('user', JSON.stringify(API.user));
      }
    } else {
      Toast.error(data?.message || '保存失败');
    }
  },

  async deleteAddress(id) {
    if (confirm('确认删除此地址？')) {
      const data = await API.del(`/addresses?id=${id}`);
      if (data?.success) { Toast.success('已删除'); Pages.Profile(); }
    }
  },

  // ===== AUTH: LOGIN =====
  Login() {
    const content = document.getElementById('page-content');
    content.innerHTML = `
      <div class="auth-page">
        <div class="auth-card">
          <div class="brand"><a href="/" data-link>🛍 朱雀商城</a></div>
          <h2>欢迎回来</h2>
          <p class="subtitle">登录您的账户继续购物</p>
          <div class="form-group"><label>邮箱</label><input class="form-input" type="email" id="login-email" placeholder="your@email.com"></div>
          <div class="form-group"><label>密码</label><input class="form-input" type="password" id="login-password" placeholder="••••••••" onkeypress="if(event.key==='Enter')Pages.doLogin()"></div>
          <button class="btn btn-primary btn-block btn-lg mt-2" onclick="Pages.doLogin()" id="login-btn">登录</button>
          <div class="auth-footer">还没有账户？ <a href="/register" data-link>立即注册</a></div>
        </div>
      </div>
    `;
  },

  async doLogin() {
    const btn = document.getElementById('login-btn');
    btn.disabled = true;
    btn.textContent = '登录中...';

    const data = await API.post('/auth/login', {
      email: document.getElementById('login-email').value,
      password: document.getElementById('login-password').value,
    });

    if (data?.success) {
      API.setAuth(data.data.access_token, data.data.user);
      Toast.success('登录成功');
      Router.go('/');
    } else {
      Toast.error(data?.message || '登录失败');
      btn.disabled = false;
      btn.textContent = '登录';
    }
  },

  // ===== AUTH: REGISTER =====
  Register() {
    const content = document.getElementById('page-content');
    content.innerHTML = `
      <div class="auth-page">
        <div class="auth-card">
          <div class="brand"><a href="/" data-link>🛍 朱雀商城</a></div>
          <h2>创建账户</h2>
          <p class="subtitle">注册成为会员，享受专属优惠</p>
          <div class="form-group"><label>姓名</label><input class="form-input" id="reg-name" placeholder="您的姓名"></div>
          <div class="form-group"><label>邮箱</label><input class="form-input" type="email" id="reg-email" placeholder="your@email.com"></div>
          <div class="form-group"><label>密码</label><input class="form-input" type="password" id="reg-password" placeholder="至少6位"></div>
          <div class="form-group">
            <label>注册类型</label>
            <select class="form-input" id="reg-role">
              <option value="customer">普通用户（买家）</option>
              <option value="seller">商家（卖家）</option>
            </select>
          </div>
          <button class="btn btn-primary btn-block btn-lg mt-2" onclick="Pages.doRegister()" id="reg-btn">注册</button>
          <div class="auth-footer">已有账户？ <a href="/login" data-link>登录</a></div>
        </div>
      </div>
    `;
  },

  async doRegister() {
    const btn = document.getElementById('reg-btn');
    btn.disabled = true;
    btn.textContent = '注册中...';

    const data = await API.post('/auth/register', {
      name: document.getElementById('reg-name').value,
      email: document.getElementById('reg-email').value,
      password: document.getElementById('reg-password').value,
      role: document.getElementById('reg-role').value,
    });

    if (data?.success) {
      Toast.success('注册成功！请登录');
      Router.go('/login');
    } else {
      Toast.error(data?.message || '注册失败');
      btn.disabled = false;
      btn.textContent = '注册';
    }
  },

  // ===== SELLER DASHBOARD =====
  async SellerDashboard() {
    if (!API.isLoggedIn()) { Router.go('/login'); return; }
    const content = document.getElementById('page-content');

    content.innerHTML = `
      <h1 class="page-title mb-2">商家中心</h1>
      <div class="dashboard-layout">
        <div class="sidebar">
          <nav class="sidebar-nav">
            <a href="#" class="active" onclick="Pages.sellerTab('products');return false;">📦 商品管理</a>
            <a href="#" onclick="Pages.sellerTab('orders');return false;">📋 订单管理</a>
            <a href="#" onclick="Pages.sellerTab('add-product');return false;">➕ 添加商品</a>
          </nav>
        </div>
        <div id="seller-content"><div class="loading"><div class="spinner"></div></div></div>
      </div>
    `;

    Pages.sellerTab('products');
  },

  async sellerTab(tab) {
    const el = document.getElementById('seller-content');
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
    event?.target?.classList?.add('active');

    if (tab === 'products') {
      el.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
      const data = await API.get('/seller/products');
      if (!data?.success || !data.data?.length) {
        el.innerHTML = `<div class="empty-state"><div class="icon">📦</div><h3>暂无商品</h3><p>添加您的第一个商品吧</p><button class="btn btn-primary mt-2" onclick="Pages.sellerTab('add-product')">添加商品</button></div>`;
        return;
      }
      el.innerHTML = `
        <div class="card">
          <div class="table-container">
            <table class="data-table">
              <thead><tr><th>商品</th><th>价格</th><th>库存</th><th>状态</th><th>销量</th><th>操作</th></tr></thead>
              <tbody>
                ${data.data.map(p => `
                  <tr>
                    <td style="display:flex;align-items:center;gap:10px;">
                      <div style="width:48px;height:48px;border-radius:6px;overflow:hidden;flex-shrink:0;">${Utils.productImage(p.images)}</div>
                      <span style="font-weight:500;">${p.name}</span>
                    </td>
                    <td class="text-vermillion" style="font-weight:700;">${Utils.formatPrice(p.price)}</td>
                    <td>${p.stock}</td>
                    <td><span class="order-status status-${p.status}">${Utils.statusText(p.status)}</span></td>
                    <td>${p.sales || 0}</td>
                    <td>
                      <button class="btn btn-secondary btn-sm" onclick="Pages.editProduct('${p.id}')">编辑</button>
                      <button class="btn btn-danger btn-sm" onclick="Pages.deleteProduct('${p.id}')">删除</button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } else if (tab === 'orders') {
      el.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
      const data = await API.get('/seller/orders');
      if (!data?.success || !data.data?.length) {
        el.innerHTML = '<div class="empty-state"><div class="icon">📋</div><h3>暂无订单</h3></div>';
        return;
      }
      el.innerHTML = data.data.map(order => `
        <div class="order-card">
          <div class="order-card-header">
            <div><span class="order-no">${order.order_no}</span><span style="margin-left:8px;color:var(--ink-muted);font-size:0.8rem;">${Utils.formatDate(order.created_at)}</span></div>
            <span class="order-status status-${order.status}">${Utils.statusText(order.status)}</span>
          </div>
          ${(order.items||[]).map(i => `
            <div class="order-item">
              <div class="order-item-info"><div class="name">${i.product_name}</div><div class="qty">x${i.quantity}</div></div>
              <div class="order-item-price">${Utils.formatPrice(i.price*i.quantity)}</div>
            </div>
          `).join('')}
          <div class="order-card-footer">
            <div class="order-total">合计: <span>${Utils.formatPrice(order.total_amount)}</span></div>
            <div class="order-actions">
              <span style="font-size:0.8rem;color:var(--ink-muted);">收货: ${order.ship_name} ${order.ship_phone}</span>
              ${order.status === 'pending_ship' ? `<button class="btn btn-primary btn-sm" onclick="Pages.shipOrder('${order.id}')">发货</button>` : ''}
            </div>
          </div>
        </div>
      `).join('');
    } else if (tab === 'add-product') {
      el.innerHTML = `
        <div class="card">
          <div class="card-body">
            <h3 style="margin-bottom:20px;">添加新商品</h3>
            <div class="form-group"><label>商品名称 *</label><input class="form-input" id="prod-name" placeholder="请输入商品名称"></div>
            <div class="form-group"><label>商品描述</label><textarea class="form-input" id="prod-desc" rows="3" placeholder="描述商品特点..."></textarea></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
              <div class="form-group"><label>售价 (¥) *</label><input class="form-input" type="number" id="prod-price" step="0.01" placeholder="0.00"></div>
              <div class="form-group"><label>原价 (¥)</label><input class="form-input" type="number" id="prod-origprice" step="0.01" placeholder="0.00"></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
              <div class="form-group"><label>库存 *</label><input class="form-input" type="number" id="prod-stock" placeholder="0"></div>
              <div class="form-group">
                <label>分类 *</label>
                <select class="form-input" id="prod-category">
                  <option value="电子产品">电子产品</option>
                  <option value="服装鞋帽">服装鞋帽</option>
                  <option value="家居家电">家居家电</option>
                  <option value="食品饮料">食品饮料</option>
                  <option value="美妆个护">美妆个护</option>
                  <option value="运动户外">运动户外</option>
                  <option value="图书音像">图书音像</option>
                  <option value="母婴玩具">母婴玩具</option>
                  <option value="汽车用品">汽车用品</option>
                  <option value="其他">其他</option>
                </select>
              </div>
            </div>
            <div class="form-group"><label>品牌</label><input class="form-input" id="prod-brand" placeholder="品牌名称"></div>
            <div class="form-group"><label>标签</label><input class="form-input" id="prod-tags" placeholder="用逗号分隔，如: 新品,热销"></div>
            <div class="form-group"><label>图片链接 (JSON数组)</label><input class="form-input" id="prod-images" placeholder='["https://..."]'></div>
            <button class="btn btn-primary btn-lg" onclick="Pages.submitProduct()">提交商品</button>
          </div>
        </div>
      `;
    }
  },

  async submitProduct() {
    const product = {
      name: document.getElementById('prod-name').value,
      description: document.getElementById('prod-desc').value,
      price: parseFloat(document.getElementById('prod-price').value) || 0,
      orig_price: parseFloat(document.getElementById('prod-origprice').value) || 0,
      stock: parseInt(document.getElementById('prod-stock').value) || 0,
      category: document.getElementById('prod-category').value,
      brand: document.getElementById('prod-brand').value,
      tags: document.getElementById('prod-tags').value,
      images: document.getElementById('prod-images').value || '[]',
    };
    if (!product.name || !product.price || !product.stock) {
      Toast.error('请填写必要信息');
      return;
    }
    const data = await API.post('/seller/products', product);
    if (data?.success) {
      Toast.success('商品已提交审核');
      Pages.sellerTab('products');
    } else {
      Toast.error(data?.message || '提交失败');
    }
  },

  async deleteProduct(id) {
    if (confirm('确认删除此商品？')) {
      await API.del(`/seller/products?id=${id}`);
      Toast.success('已删除');
      Pages.sellerTab('products');
    }
  },

  async shipOrder(orderId) {
    const trackingNo = prompt('请输入物流单号:');
    if (trackingNo) {
      const data = await API.post(`/seller/orders/ship?id=${orderId}`, { tracking_no: trackingNo });
      if (data?.success) { Toast.success('已发货'); Pages.sellerTab('orders'); }
      else Toast.error(data?.message || '操作失败');
    }
  },

  // ===== ADMIN DASHBOARD =====
  async AdminDashboard() {
    if (!API.isLoggedIn() || API.user?.role !== 'admin') {
      Toast.error('需要管理员权限');
      Router.go('/');
      return;
    }
    const content = document.getElementById('page-content');

    content.innerHTML = `
      <h1 class="page-title mb-2">管理后台</h1>
      <div class="dashboard-layout">
        <div class="sidebar">
          <nav class="sidebar-nav">
            <a href="#" class="active" onclick="Pages.adminTab('overview');return false;">📊 总览</a>
            <a href="#" onclick="Pages.adminTab('users');return false;">👥 用户管理</a>
            <a href="#" onclick="Pages.adminTab('products');return false;">📦 商品审核</a>
            <a href="#" onclick="Pages.adminTab('orders');return false;">📋 订单管理</a>
          </nav>
        </div>
        <div id="admin-content"><div class="loading"><div class="spinner"></div></div></div>
      </div>
    `;

    Pages.adminTab('overview');
  },

  async adminTab(tab) {
    const el = document.getElementById('admin-content');
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
    event?.target?.classList?.add('active');

    if (tab === 'overview') {
      el.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
      const data = await API.get('/admin/dashboard');
      if (!data?.success) { el.innerHTML = '<p>加载失败</p>'; return; }
      const s = data.data;
      el.innerHTML = `
        <div class="stats-grid">
          <div class="stat-card"><div class="stat-label">总用户数</div><div class="stat-value">${s.total_users}</div></div>
          <div class="stat-card"><div class="stat-label">总商品数</div><div class="stat-value">${s.total_products}</div></div>
          <div class="stat-card"><div class="stat-label">总订单数</div><div class="stat-value">${s.total_orders}</div></div>
          <div class="stat-card"><div class="stat-label">总收入</div><div class="stat-value" style="color:var(--vermillion);">${Utils.formatPrice(s.total_revenue)}</div></div>
          <div class="stat-card"><div class="stat-label">今日订单</div><div class="stat-value">${s.today_orders}</div><div class="stat-sub">+${Utils.formatPrice(s.today_revenue)}</div></div>
          <div class="stat-card"><div class="stat-label">待审核商品</div><div class="stat-value" style="color:var(--warning);">${s.pending_review}</div></div>
        </div>
      `;
    } else if (tab === 'users') {
      el.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
      const data = await API.get('/admin/users');
      el.innerHTML = `
        <div class="card">
          <div class="table-container">
            <table class="data-table">
              <thead><tr><th>用户</th><th>邮箱</th><th>角色</th><th>注册时间</th><th>操作</th></tr></thead>
              <tbody>
                ${(data?.data||[]).map(u => `
                  <tr>
                    <td style="font-weight:500;">${u.name || '—'}</td>
                    <td>${u.email}</td>
                    <td><span class="order-status status-${u.role === 'admin' ? 'completed' : 'pending_ship'}">${u.role}</span></td>
                    <td style="font-size:0.85rem;color:var(--ink-muted);">${Utils.formatDate(u.created_at)}</td>
                    <td>
                      <select class="form-input" style="width:120px;padding:4px 8px;font-size:0.8rem;" onchange="Pages.changeUserRole('${u.id}',this.value)">
                        <option ${u.role==='customer'?'selected':''} value="customer">customer</option>
                        <option ${u.role==='seller'?'selected':''} value="seller">seller</option>
                        <option ${u.role==='admin'?'selected':''} value="admin">admin</option>
                        <option ${u.role==='support'?'selected':''} value="support">support</option>
                      </select>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } else if (tab === 'products') {
      el.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
      const data = await API.get('/admin/products?status=pending');
      if (!data?.data?.length) {
        el.innerHTML = '<div class="empty-state"><div class="icon">✅</div><h3>没有待审核的商品</h3></div>';
        return;
      }
      el.innerHTML = `
        <div class="card">
          <div class="table-container">
            <table class="data-table">
              <thead><tr><th>商品</th><th>商家</th><th>价格</th><th>库存</th><th>分类</th><th>操作</th></tr></thead>
              <tbody>
                ${data.data.map(p => `
                  <tr>
                    <td style="font-weight:500;">${p.name}</td>
                    <td>${p.seller_name || '—'}</td>
                    <td class="text-vermillion">${Utils.formatPrice(p.price)}</td>
                    <td>${p.stock}</td>
                    <td>${p.category}</td>
                    <td>
                      <button class="btn btn-success btn-sm" onclick="Pages.reviewProduct('${p.id}','approved')">通过</button>
                      <button class="btn btn-danger btn-sm" onclick="Pages.reviewProduct('${p.id}','rejected')">拒绝</button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } else if (tab === 'orders') {
      el.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
      const data = await API.get('/admin/orders');
      if (!data?.data?.length) {
        el.innerHTML = '<div class="empty-state"><div class="icon">📋</div><h3>暂无订单</h3></div>';
        return;
      }
      el.innerHTML = `
        <div class="card">
          <div class="table-container">
            <table class="data-table">
              <thead><tr><th>订单号</th><th>金额</th><th>状态</th><th>收货人</th><th>时间</th><th>操作</th></tr></thead>
              <tbody>
                ${data.data.map(o => `
                  <tr>
                    <td style="font-weight:500;font-size:0.85rem;">${o.order_no}</td>
                    <td class="text-vermillion" style="font-weight:700;">${Utils.formatPrice(o.total_amount)}</td>
                    <td><span class="order-status status-${o.status}">${Utils.statusText(o.status)}</span></td>
                    <td>${o.ship_name || '—'}</td>
                    <td style="font-size:0.8rem;color:var(--ink-muted);">${Utils.formatDate(o.created_at)}</td>
                    <td>
                      <select class="form-input" style="width:110px;padding:4px 8px;font-size:0.8rem;" onchange="Pages.adminUpdateOrder('${o.id}',this.value)">
                        <option ${o.status==='pending_payment'?'selected':''} value="pending_payment">待支付</option>
                        <option ${o.status==='pending_ship'?'selected':''} value="pending_ship">待发货</option>
                        <option ${o.status==='shipped'?'selected':''} value="shipped">已发货</option>
                        <option ${o.status==='completed'?'selected':''} value="completed">已完成</option>
                        <option ${o.status==='cancelled'?'selected':''} value="cancelled">已取消</option>
                      </select>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    }
  },

  async changeUserRole(userId, role) {
    const data = await API.put(`/admin/users?id=${userId}`, { role });
    if (data?.success) Toast.success('角色已更新');
    else Toast.error('更新失败');
  },

  async reviewProduct(productId, status) {
    const data = await API.put(`/admin/products?id=${productId}`, { status });
    if (data?.success) {
      Toast.success(data.message);
      Pages.adminTab('products');
    } else {
      Toast.error('操作失败');
    }
  },

  async adminUpdateOrder(orderId, status) {
    const data = await API.put(`/admin/orders?id=${orderId}`, { status });
    if (data?.success) Toast.success('订单已更新');
    else Toast.error('更新失败');
  },

  editProduct(id) {
    // simplified - in production would load product data into form
    Toast.warning('编辑功能请在商家中心使用');
  },
};

// ==================== Init ====================
document.addEventListener('DOMContentLoaded', () => App.init());
