# 朱雀商城 (Vermillion Mall) — E-Commerce Platform

Full-stack e-commerce platform built with **Go** (stdlib only) + **Supabase** + **Vanilla JS SPA**.

## Quick Start

### 1. Set up Supabase
1. Create a project at [supabase.com](https://supabase.com)
2. Run `supabase/schema.sql` in the SQL Editor
3. Note your project URL, anon key, service key, and JWT secret

### 2. Configure Environment
```bash
export PORT=8080
export SUPABASE_URL=https://your-project.supabase.co
export SUPABASE_ANON_KEY=your-anon-key
export SUPABASE_SERVICE_KEY=your-service-key
export JWT_SECRET=your-jwt-secret
```

### 3. Run
```bash
cd ecommerce-platform
go run main.go
```

### 4. Open
Visit `http://localhost:8080`

## Features
- **Customer:** Browse, search, cart, checkout, orders, reviews
- **Seller:** Product management, order fulfillment, shipping
- **Admin:** Dashboard stats, user roles, product approval, order management
- **Auth:** Registration (customer/seller), JWT login, role-based access

## Tech Stack
- **Backend:** Go 1.21 (standard library only, zero dependencies)
- **Database:** Supabase (PostgreSQL + RLS + Auth)
- **Frontend:** Vanilla HTML/CSS/JS single-page application
- **Theme:** "Vermillion" — warm premium aesthetic (朱雀红 + 金色)

## Project Structure
```
├── main.go              # HTTP server, routes, static files
├── config/              # Environment configuration
├── middleware/           # CORS, logging, JWT auth, role checks
├── handlers/            # API handlers (auth, product, cart, order, admin)
├── models/              # Go struct definitions
├── supabase/
│   ├── schema.sql       # Complete database schema + RLS + seeds
│   └── client.go        # Custom Supabase REST client
└── static/
    ├── pages/index.html # SPA entry point
    ├── css/style.css    # Vermillion theme
    └── js/app.js        # SPA router + API client + all pages
```
