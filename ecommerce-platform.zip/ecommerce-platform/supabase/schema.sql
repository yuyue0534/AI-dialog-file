-- ============================================================
-- E-Commerce Platform - Supabase Schema
-- Run this SQL in your Supabase SQL Editor
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ========== Profiles ==========
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    name TEXT NOT NULL DEFAULT '',
    phone TEXT DEFAULT '',
    role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','seller','admin','support')),
    avatar TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, name, role)
    VALUES (NEW.id, NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'name',''),
        COALESCE(NEW.raw_user_meta_data->>'role','customer'));
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ========== Addresses ==========
CREATE TABLE addresses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    province TEXT DEFAULT '',
    city TEXT DEFAULT '',
    district TEXT DEFAULT '',
    detail TEXT NOT NULL,
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ========== Categories ==========
CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL UNIQUE,
    icon TEXT DEFAULT '',
    sort_order INT DEFAULT 0
);

INSERT INTO categories (name, icon, sort_order) VALUES
    ('电子产品','💻',1),('服装鞋帽','👔',2),('家居家电','🏠',3),
    ('食品饮料','🍜',4),('美妆个护','💄',5),('运动户外','⚽',6),
    ('图书音像','📚',7),('母婴玩具','🧸',8),('汽车用品','🚗',9),('其他','📦',10);

-- ========== Products ==========
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    seller_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    price DECIMAL(12,2) NOT NULL CHECK (price >= 0),
    orig_price DECIMAL(12,2) DEFAULT 0,
    stock INT NOT NULL DEFAULT 0 CHECK (stock >= 0),
    category TEXT NOT NULL DEFAULT '其他',
    tags TEXT DEFAULT '',
    images TEXT DEFAULT '[]',
    brand TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','offline')),
    sales INT DEFAULT 0,
    rating DECIMAL(2,1) DEFAULT 0,
    rating_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_products_seller ON products(seller_id);
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_status ON products(status);

-- ========== Cart ==========
CREATE TABLE cart_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    selected BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, product_id)
);

-- ========== Orders ==========
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_no TEXT NOT NULL UNIQUE,
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    total_amount DECIMAL(12,2) NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending_payment'
        CHECK (status IN ('pending_payment','pending_ship','shipped','completed','cancelled','refunding')),
    payment_method TEXT DEFAULT '',
    ship_name TEXT DEFAULT '',
    ship_phone TEXT DEFAULT '',
    ship_address TEXT DEFAULT '',
    tracking_no TEXT DEFAULT '',
    remark TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);

-- ========== Order Items ==========
CREATE TABLE order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id),
    product_name TEXT NOT NULL,
    product_image TEXT DEFAULT '',
    price DECIMAL(12,2) NOT NULL,
    quantity INT NOT NULL,
    seller_id UUID NOT NULL REFERENCES profiles(id)
);

CREATE INDEX idx_order_items_order ON order_items(order_id);

-- ========== Reviews ==========
CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    order_id UUID REFERENCES orders(id),
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    content TEXT DEFAULT '',
    images TEXT DEFAULT '[]',
    reply TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'approved' CHECK (status IN ('pending','approved','rejected')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_reviews_product ON reviews(product_id);

-- ========== Order number generator ==========
CREATE OR REPLACE FUNCTION generate_order_no()
RETURNS TEXT AS $$
BEGIN
    RETURN 'ORD' || TO_CHAR(NOW(),'YYYYMMDD') || LPAD(FLOOR(RANDOM()*1000000)::TEXT,6,'0');
END;
$$ LANGUAGE plpgsql;

-- ========== RLS ==========
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profiles_select" ON profiles FOR SELECT USING (true);
CREATE POLICY "profiles_update" ON profiles FOR UPDATE USING (auth.uid()=id);
CREATE POLICY "addr_all" ON addresses FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "cat_select" ON categories FOR SELECT USING (true);
CREATE POLICY "prod_select" ON products FOR SELECT USING (status='approved' OR seller_id=auth.uid());
CREATE POLICY "prod_insert" ON products FOR INSERT WITH CHECK (auth.uid()=seller_id);
CREATE POLICY "prod_update" ON products FOR UPDATE USING (auth.uid()=seller_id);
CREATE POLICY "prod_delete" ON products FOR DELETE USING (auth.uid()=seller_id);
CREATE POLICY "cart_all" ON cart_items FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "orders_select" ON orders FOR SELECT USING (auth.uid()=user_id);
CREATE POLICY "orders_insert" ON orders FOR INSERT WITH CHECK (auth.uid()=user_id);
CREATE POLICY "orders_update" ON orders FOR UPDATE USING (auth.uid()=user_id);
CREATE POLICY "oi_select" ON order_items FOR SELECT USING (
    EXISTS(SELECT 1 FROM orders WHERE orders.id=order_items.order_id AND orders.user_id=auth.uid()) OR seller_id=auth.uid());
CREATE POLICY "oi_insert" ON order_items FOR INSERT WITH CHECK (
    EXISTS(SELECT 1 FROM orders WHERE orders.id=order_items.order_id AND orders.user_id=auth.uid()));
CREATE POLICY "reviews_select" ON reviews FOR SELECT USING (true);
CREATE POLICY "reviews_insert" ON reviews FOR INSERT WITH CHECK (auth.uid()=user_id);
CREATE POLICY "reviews_update" ON reviews FOR UPDATE USING (auth.uid()=user_id);
