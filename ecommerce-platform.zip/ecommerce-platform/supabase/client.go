package supabase

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
)

type Client struct {
	BaseURL    string
	APIKey     string
	ServiceKey string
	HTTPClient *http.Client
}

func NewClient(baseURL, apiKey, serviceKey string) *Client {
	return &Client{
		BaseURL:    strings.TrimRight(baseURL, "/"),
		APIKey:     apiKey,
		ServiceKey: serviceKey,
		HTTPClient: &http.Client{},
	}
}

// ==================== Auth ====================

type AuthSignUpRequest struct {
	Email    string                 `json:"email"`
	Password string                 `json:"password"`
	Data     map[string]interface{} `json:"data,omitempty"`
}

type AuthSignInRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type AuthTokenResponse struct {
	AccessToken  string      `json:"access_token"`
	TokenType    string      `json:"token_type"`
	ExpiresIn    int         `json:"expires_in"`
	RefreshToken string      `json:"refresh_token"`
	User         interface{} `json:"user"`
}

func (c *Client) SignUp(email, password, name, role string) (*AuthTokenResponse, error) {
	body := map[string]interface{}{
		"email":    email,
		"password": password,
		"data": map[string]interface{}{
			"name": name,
			"role": role,
		},
	}
	jsonBody, _ := json.Marshal(body)

	req, _ := http.NewRequest("POST", c.BaseURL+"/auth/v1/signup", bytes.NewReader(jsonBody))
	req.Header.Set("apikey", c.APIKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("signup failed: %s", string(respBody))
	}

	var result AuthTokenResponse
	json.Unmarshal(respBody, &result)
	return &result, nil
}

func (c *Client) SignIn(email, password string) (*AuthTokenResponse, error) {
	body := map[string]interface{}{
		"email":    email,
		"password": password,
	}
	jsonBody, _ := json.Marshal(body)

	req, _ := http.NewRequest("POST", c.BaseURL+"/auth/v1/token?grant_type=password", bytes.NewReader(jsonBody))
	req.Header.Set("apikey", c.APIKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("signin failed: %s", string(respBody))
	}

	var result AuthTokenResponse
	json.Unmarshal(respBody, &result)
	return &result, nil
}

func (c *Client) GetUser(token string) (map[string]interface{}, error) {
	req, _ := http.NewRequest("GET", c.BaseURL+"/auth/v1/user", nil)
	req.Header.Set("apikey", c.APIKey)
	req.Header.Set("Authorization", "Bearer "+token)

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("get user failed: %s", string(respBody))
	}

	var result map[string]interface{}
	json.Unmarshal(respBody, &result)
	return result, nil
}

// ==================== REST (PostgREST) ====================

type QueryBuilder struct {
	client  *Client
	table   string
	token   string
	method  string
	body    interface{}
	params  url.Values
	headers map[string]string
	useServiceKey bool
}

func (c *Client) From(table string) *QueryBuilder {
	return &QueryBuilder{
		client:  c,
		table:   table,
		params:  url.Values{},
		headers: make(map[string]string),
	}
}

func (q *QueryBuilder) Auth(token string) *QueryBuilder {
	q.token = token
	return q
}

func (q *QueryBuilder) AsService() *QueryBuilder {
	q.useServiceKey = true
	return q
}

func (q *QueryBuilder) Select(columns string) *QueryBuilder {
	q.method = "GET"
	q.params.Set("select", columns)
	return q
}

func (q *QueryBuilder) Insert(data interface{}) *QueryBuilder {
	q.method = "POST"
	q.body = data
	q.headers["Prefer"] = "return=representation"
	return q
}

func (q *QueryBuilder) Upsert(data interface{}) *QueryBuilder {
	q.method = "POST"
	q.body = data
	q.headers["Prefer"] = "return=representation,resolution=merge-duplicates"
	return q
}

func (q *QueryBuilder) Update(data interface{}) *QueryBuilder {
	q.method = "PATCH"
	q.body = data
	q.headers["Prefer"] = "return=representation"
	return q
}

func (q *QueryBuilder) Delete() *QueryBuilder {
	q.method = "DELETE"
	q.headers["Prefer"] = "return=representation"
	return q
}

func (q *QueryBuilder) Eq(column, value string) *QueryBuilder {
	q.params.Set(column, "eq."+value)
	return q
}

func (q *QueryBuilder) Neq(column, value string) *QueryBuilder {
	q.params.Set(column, "neq."+value)
	return q
}

func (q *QueryBuilder) Gt(column, value string) *QueryBuilder {
	q.params.Set(column, "gt."+value)
	return q
}

func (q *QueryBuilder) Gte(column, value string) *QueryBuilder {
	q.params.Set(column, "gte."+value)
	return q
}

func (q *QueryBuilder) Lt(column, value string) *QueryBuilder {
	q.params.Set(column, "lt."+value)
	return q
}

func (q *QueryBuilder) Like(column, value string) *QueryBuilder {
	q.params.Set(column, "ilike.*"+value+"*")
	return q
}

func (q *QueryBuilder) In(column string, values []string) *QueryBuilder {
	q.params.Set(column, "in.("+strings.Join(values, ",")+")")
	return q
}

func (q *QueryBuilder) Order(column string, ascending bool) *QueryBuilder {
	dir := "desc"
	if ascending {
		dir = "asc"
	}
	q.params.Set("order", column+"."+dir)
	return q
}

func (q *QueryBuilder) Limit(n int) *QueryBuilder {
	q.params.Set("limit", fmt.Sprintf("%d", n))
	return q
}

func (q *QueryBuilder) Offset(n int) *QueryBuilder {
	q.params.Set("offset", fmt.Sprintf("%d", n))
	return q
}

func (q *QueryBuilder) Single() *QueryBuilder {
	q.headers["Accept"] = "application/vnd.pgrst.object+json"
	q.params.Set("limit", "1")
	return q
}

func (q *QueryBuilder) RangeCount() *QueryBuilder {
	q.headers["Prefer"] = "count=exact"
	return q
}

func (q *QueryBuilder) Execute() ([]byte, http.Header, error) {
	u := q.client.BaseURL + "/rest/v1/" + q.table
	if encoded := q.params.Encode(); encoded != "" {
		u += "?" + encoded
	}

	var bodyReader io.Reader
	if q.body != nil {
		jsonBody, err := json.Marshal(q.body)
		if err != nil {
			return nil, nil, err
		}
		bodyReader = bytes.NewReader(jsonBody)
	}

	if q.method == "" {
		q.method = "GET"
	}

	req, err := http.NewRequest(q.method, u, bodyReader)
	if err != nil {
		return nil, nil, err
	}

	req.Header.Set("Content-Type", "application/json")

	if q.useServiceKey && q.client.ServiceKey != "" {
		req.Header.Set("apikey", q.client.ServiceKey)
		req.Header.Set("Authorization", "Bearer "+q.client.ServiceKey)
	} else {
		req.Header.Set("apikey", q.client.APIKey)
		if q.token != "" {
			req.Header.Set("Authorization", "Bearer "+q.token)
		} else {
			req.Header.Set("Authorization", "Bearer "+q.client.APIKey)
		}
	}

	for k, v := range q.headers {
		req.Header.Set(k, v)
	}

	resp, err := q.client.HTTPClient.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		return nil, resp.Header, fmt.Errorf("supabase error (%d): %s", resp.StatusCode, string(respBody))
	}

	return respBody, resp.Header, nil
}

// ==================== RPC ====================

func (c *Client) RPC(fn string, params interface{}, token string) ([]byte, error) {
	jsonBody, _ := json.Marshal(params)
	req, _ := http.NewRequest("POST", c.BaseURL+"/rest/v1/rpc/"+fn, bytes.NewReader(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("apikey", c.APIKey)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	} else {
		req.Header.Set("Authorization", "Bearer "+c.APIKey)
	}

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	return io.ReadAll(resp.Body)
}
