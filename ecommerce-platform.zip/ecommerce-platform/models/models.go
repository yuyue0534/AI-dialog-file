package models

import "time"

// ========== User ==========

type User struct {
	ID        string    `json:"id"`
	Email     string    `json:"email"`
	Name      string    `json:"name"`
	Phone     string    `json:"phone"`
	Role      string    `json:"role"` // customer, seller, admin, support
	Avatar    string    `json:"avatar"`
	CreatedAt time.Time `json:"created_at"`
}

type RegisterRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
	Name     string `json:"name"`
	Phone    string `json:"phone"`
	Role     string `json:"role"`
}

type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type AuthResponse struct {
	AccessToken string `json:"access_token"`
	User        User   `json:"user"`
}

// ========== Address ==========

type Address struct {
	ID        string `json:"id"`
	UserID    string `json:"user_id"`
	Name      string `json:"name"`
	Phone     string `json:"phone"`
	Province  string `json:"province"`
	City      string `json:"city"`
	District  string `json:"district"`
	Detail    string `json:"detail"`
	IsDefault bool   `json:"is_default"`
}

// ========== Product ==========

type Product struct {
	ID          string    `json:"id"`
	SellerID    string    `json:"seller_id"`
	SellerName  string    `json:"seller_name"`
	Name        string    `json:"name"`
	Description string    `json:"description"`
	Price       float64   `json:"price"`
	OrigPrice   float64   `json:"orig_price"`
	Stock       int       `json:"stock"`
	Category    string    `json:"category"`
	Tags        string    `json:"tags"`
	Images      string    `json:"images"` // JSON array of URLs
	Brand       string    `json:"brand"`
	Status      string    `json:"status"` // pending, approved, rejected, offline
	Sales       int       `json:"sales"`
	Rating      float64   `json:"rating"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type ProductCreateRequest struct {
	Name        string  `json:"name"`
	Description string  `json:"description"`
	Price       float64 `json:"price"`
	OrigPrice   float64 `json:"orig_price"`
	Stock       int     `json:"stock"`
	Category    string  `json:"category"`
	Tags        string  `json:"tags"`
	Images      string  `json:"images"`
	Brand       string  `json:"brand"`
}

// ========== Cart ==========

type CartItem struct {
	ID          string  `json:"id"`
	UserID      string  `json:"user_id"`
	ProductID   string  `json:"product_id"`
	ProductName string  `json:"product_name"`
	ProductImg  string  `json:"product_image"`
	Price       float64 `json:"price"`
	Quantity    int     `json:"quantity"`
	Selected    bool    `json:"selected"`
}

type CartAddRequest struct {
	ProductID string `json:"product_id"`
	Quantity  int    `json:"quantity"`
}

// ========== Order ==========

type Order struct {
	ID            string      `json:"id"`
	OrderNo       string      `json:"order_no"`
	UserID        string      `json:"user_id"`
	TotalAmount   float64     `json:"total_amount"`
	Status        string      `json:"status"` // pending_payment, pending_ship, shipped, completed, cancelled, refunding
	PaymentMethod string      `json:"payment_method"`
	ShipAddress   string      `json:"ship_address"`
	ShipName      string      `json:"ship_name"`
	ShipPhone     string      `json:"ship_phone"`
	TrackingNo    string      `json:"tracking_no"`
	Remark        string      `json:"remark"`
	Items         []OrderItem `json:"items"`
	CreatedAt     time.Time   `json:"created_at"`
	UpdatedAt     time.Time   `json:"updated_at"`
}

type OrderItem struct {
	ID          string  `json:"id"`
	OrderID     string  `json:"order_id"`
	ProductID   string  `json:"product_id"`
	ProductName string  `json:"product_name"`
	ProductImg  string  `json:"product_image"`
	Price       float64 `json:"price"`
	Quantity    int     `json:"quantity"`
	SellerID    string  `json:"seller_id"`
}

type OrderCreateRequest struct {
	AddressID     string `json:"address_id"`
	PaymentMethod string `json:"payment_method"`
	Remark        string `json:"remark"`
	CartItemIDs   []string `json:"cart_item_ids"`
}

// ========== Review ==========

type Review struct {
	ID        string    `json:"id"`
	ProductID string    `json:"product_id"`
	UserID    string    `json:"user_id"`
	UserName  string    `json:"user_name"`
	OrderID   string    `json:"order_id"`
	Rating    int       `json:"rating"`
	Content   string    `json:"content"`
	Images    string    `json:"images"`
	Reply     string    `json:"reply"`
	Status    string    `json:"status"` // pending, approved, rejected
	CreatedAt time.Time `json:"created_at"`
}

// ========== Stats ==========

type DashboardStats struct {
	TotalUsers    int     `json:"total_users"`
	TotalProducts int     `json:"total_products"`
	TotalOrders   int     `json:"total_orders"`
	TotalRevenue  float64 `json:"total_revenue"`
	TodayOrders   int     `json:"today_orders"`
	TodayRevenue  float64 `json:"today_revenue"`
	PendingReview int     `json:"pending_review"`
}

// ========== API Response ==========

type APIResponse struct {
	Success bool        `json:"success"`
	Message string      `json:"message"`
	Data    interface{} `json:"data,omitempty"`
}

type PaginatedResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data"`
	Total   int         `json:"total"`
	Page    int         `json:"page"`
	Limit   int         `json:"limit"`
}
