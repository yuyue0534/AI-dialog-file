package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"ecommerce-platform/models"
	"ecommerce-platform/supabase"
)

type AdminHandler struct {
	SB *supabase.Client
}

func (h *AdminHandler) Dashboard(w http.ResponseWriter, r *http.Request) {
	stats := models.DashboardStats{}

	// Total users
	userData, _, _ := h.SB.From("profiles").Select("id").AsService().Execute()
	var users []map[string]interface{}
	json.Unmarshal(userData, &users)
	stats.TotalUsers = len(users)

	// Total products
	prodData, _, _ := h.SB.From("products").Select("id").AsService().Execute()
	var prods []map[string]interface{}
	json.Unmarshal(prodData, &prods)
	stats.TotalProducts = len(prods)

	// Total orders and revenue
	orderData, _, _ := h.SB.From("orders").Select("id,total_amount,status,created_at").AsService().Execute()
	var orders []map[string]interface{}
	json.Unmarshal(orderData, &orders)
	stats.TotalOrders = len(orders)

	today := time.Now().Format("2006-01-02")
	for _, o := range orders {
		amount, _ := o["total_amount"].(float64)
		st, _ := o["status"].(string)
		if st != "cancelled" {
			stats.TotalRevenue += amount
		}
		createdAt, _ := o["created_at"].(string)
		if len(createdAt) >= 10 && createdAt[:10] == today {
			stats.TodayOrders++
			if st != "cancelled" {
				stats.TodayRevenue += amount
			}
		}
	}

	// Pending review products
	pendingData, _, _ := h.SB.From("products").Select("id").Eq("status", "pending").AsService().Execute()
	var pending []map[string]interface{}
	json.Unmarshal(pendingData, &pending)
	stats.PendingReview = len(pending)

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: stats})
}

func (h *AdminHandler) ListUsers(w http.ResponseWriter, r *http.Request) {
	page := getQueryInt(r, "page", 1)
	limit := getQueryInt(r, "limit", 20)

	q := h.SB.From("profiles").Select("*").Order("created_at", false).Limit(limit).Offset((page - 1) * limit).AsService()

	role := r.URL.Query().Get("role")
	if role != "" {
		q = q.Eq("role", role)
	}
	search := r.URL.Query().Get("search")
	if search != "" {
		q = q.Like("name", search)
	}

	data, _, err := q.Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var users []map[string]interface{}
	json.Unmarshal(data, &users)
	if users == nil {
		users = []map[string]interface{}{}
	}
	writeJSON(w, http.StatusOK, models.PaginatedResponse{Success: true, Data: users, Page: page, Limit: limit})
}

func (h *AdminHandler) UpdateUserRole(w http.ResponseWriter, r *http.Request) {
	userID := r.URL.Query().Get("id")

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)

	role, ok := req["role"].(string)
	if !ok {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "缺少角色"})
		return
	}

	_, _, err := h.SB.From("profiles").Update(map[string]interface{}{"role": role}).Eq("id", userID).AsService().Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "更新失败"})
		return
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "角色已更新"})
}

func (h *AdminHandler) ListProducts(w http.ResponseWriter, r *http.Request) {
	page := getQueryInt(r, "page", 1)
	limit := getQueryInt(r, "limit", 20)

	q := h.SB.From("products").Select("*,profiles!products_seller_id_fkey(name)").Order("created_at", false).Limit(limit).Offset((page - 1) * limit).AsService()

	status := r.URL.Query().Get("status")
	if status != "" {
		q = q.Eq("status", status)
	}
	search := r.URL.Query().Get("search")
	if search != "" {
		q = q.Like("name", search)
	}

	data, _, err := q.Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var products []map[string]interface{}
	json.Unmarshal(data, &products)
	if products == nil {
		products = []map[string]interface{}{}
	}
	for i, p := range products {
		if prof, ok := p["profiles"].(map[string]interface{}); ok {
			products[i]["seller_name"] = prof["name"]
		}
		delete(products[i], "profiles")
	}
	writeJSON(w, http.StatusOK, models.PaginatedResponse{Success: true, Data: products, Page: page, Limit: limit})
}

func (h *AdminHandler) ReviewProduct(w http.ResponseWriter, r *http.Request) {
	productID := r.URL.Query().Get("id")

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)

	status, _ := req["status"].(string)
	if status != "approved" && status != "rejected" {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "无效的状态"})
		return
	}

	_, _, err := h.SB.From("products").Update(map[string]interface{}{
		"status":     status,
		"updated_at": time.Now().Format(time.RFC3339),
	}).Eq("id", productID).AsService().Execute()

	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "审核失败"})
		return
	}

	msg := "已通过审核"
	if status == "rejected" {
		msg = "已拒绝"
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: msg})
}

func (h *AdminHandler) ListOrders(w http.ResponseWriter, r *http.Request) {
	page := getQueryInt(r, "page", 1)
	limit := getQueryInt(r, "limit", 20)

	q := h.SB.From("orders").Select("*").Order("created_at", false).Limit(limit).Offset((page - 1) * limit).AsService()

	status := r.URL.Query().Get("status")
	if status != "" {
		q = q.Eq("status", status)
	}

	data, _, err := q.Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var orders []map[string]interface{}
	json.Unmarshal(data, &orders)
	if orders == nil {
		orders = []map[string]interface{}{}
	}

	for i, order := range orders {
		oid, _ := order["id"].(string)
		iData, _, _ := h.SB.From("order_items").Select("*").Eq("order_id", oid).AsService().Execute()
		var items []map[string]interface{}
		json.Unmarshal(iData, &items)
		if items == nil {
			items = []map[string]interface{}{}
		}
		orders[i]["items"] = items
	}

	writeJSON(w, http.StatusOK, models.PaginatedResponse{Success: true, Data: orders, Page: page, Limit: limit})
}

func (h *AdminHandler) UpdateOrder(w http.ResponseWriter, r *http.Request) {
	orderID := r.URL.Query().Get("id")

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)

	allowed := map[string]bool{"status": true, "tracking_no": true}
	clean := make(map[string]interface{})
	for k, v := range req {
		if allowed[k] {
			clean[k] = v
		}
	}
	clean["updated_at"] = time.Now().Format(time.RFC3339)

	_, _, err := h.SB.From("orders").Update(clean).Eq("id", orderID).AsService().Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "更新失败"})
		return
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "更新成功"})
}
