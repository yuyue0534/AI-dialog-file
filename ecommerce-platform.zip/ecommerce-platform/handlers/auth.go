package handlers

import (
	"encoding/json"
	"net/http"

	"ecommerce-platform/middleware"
	"ecommerce-platform/models"
	"ecommerce-platform/supabase"
)

type AuthHandler struct {
	SB *supabase.Client
}

func (h *AuthHandler) Register(w http.ResponseWriter, r *http.Request) {
	var req models.RegisterRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "无效的请求数据"})
		return
	}

	if req.Email == "" || req.Password == "" || req.Name == "" {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "邮箱、密码和姓名不能为空"})
		return
	}
	if req.Role == "" {
		req.Role = "customer"
	}

	result, err := h.SB.SignUp(req.Email, req.Password, req.Name, req.Role)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "注册失败: " + err.Error()})
		return
	}

	writeJSON(w, http.StatusOK, models.APIResponse{
		Success: true,
		Message: "注册成功",
		Data:    result,
	})
}

func (h *AuthHandler) Login(w http.ResponseWriter, r *http.Request) {
	var req models.LoginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "无效的请求数据"})
		return
	}

	result, err := h.SB.SignIn(req.Email, req.Password)
	if err != nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{Success: false, Message: "登录失败: " + err.Error()})
		return
	}

	// Get profile
	userMap, _ := result.User.(map[string]interface{})
	userID, _ := userMap["id"].(string)

	profileData, _, _ := h.SB.From("profiles").Select("*").Eq("id", userID).Auth(result.AccessToken).Single().Execute()
	var profile map[string]interface{}
	json.Unmarshal(profileData, &profile)

	writeJSON(w, http.StatusOK, models.APIResponse{
		Success: true,
		Message: "登录成功",
		Data: map[string]interface{}{
			"access_token": result.AccessToken,
			"user":         profile,
		},
	})
}

func (h *AuthHandler) GetProfile(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	data, _, err := h.SB.From("profiles").Select("*").Eq("id", userID).Auth(token).Single().Execute()
	if err != nil {
		writeJSON(w, http.StatusNotFound, models.APIResponse{Success: false, Message: "用户不存在"})
		return
	}

	var profile map[string]interface{}
	json.Unmarshal(data, &profile)
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: profile})
}

func (h *AuthHandler) UpdateProfile(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	var updates map[string]interface{}
	json.NewDecoder(r.Body).Decode(&updates)

	// Only allow certain fields
	allowed := map[string]bool{"name": true, "phone": true, "avatar": true}
	clean := make(map[string]interface{})
	for k, v := range updates {
		if allowed[k] {
			clean[k] = v
		}
	}

	data, _, err := h.SB.From("profiles").Update(clean).Eq("id", userID).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "更新失败"})
		return
	}

	var result []map[string]interface{}
	json.Unmarshal(data, &result)
	if len(result) > 0 {
		writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: result[0]})
	} else {
		writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "更新成功"})
	}
}

// ========== Address ==========

func (h *AuthHandler) GetAddresses(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	data, _, err := h.SB.From("addresses").Select("*").Eq("user_id", userID).Order("is_default", false).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var addresses []map[string]interface{}
	json.Unmarshal(data, &addresses)
	if addresses == nil {
		addresses = []map[string]interface{}{}
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: addresses})
}

func (h *AuthHandler) CreateAddress(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	var addr map[string]interface{}
	json.NewDecoder(r.Body).Decode(&addr)
	addr["user_id"] = userID

	data, _, err := h.SB.From("addresses").Insert(addr).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var result []map[string]interface{}
	json.Unmarshal(data, &result)
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: result})
}

func (h *AuthHandler) UpdateAddress(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	addrID := r.URL.Query().Get("id")

	var addr map[string]interface{}
	json.NewDecoder(r.Body).Decode(&addr)
	delete(addr, "id")
	delete(addr, "user_id")

	data, _, err := h.SB.From("addresses").Update(addr).Eq("id", addrID).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var result []map[string]interface{}
	json.Unmarshal(data, &result)
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: result})
}

func (h *AuthHandler) DeleteAddress(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	addrID := r.URL.Query().Get("id")

	_, _, err := h.SB.From("addresses").Delete().Eq("id", addrID).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "删除成功"})
}
