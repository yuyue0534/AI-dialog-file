package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"ecommerce-platform/middleware"
	"ecommerce-platform/models"
	"ecommerce-platform/supabase"
)

type ProductHandler struct {
	SB *supabase.Client
}

func (h *ProductHandler) List(w http.ResponseWriter, r *http.Request) {
	q := h.SB.From("products").Select("*,profiles!products_seller_id_fkey(name)")

	// Filters
	category := r.URL.Query().Get("category")
	if category != "" {
		q = q.Eq("category", category)
	}
	search := r.URL.Query().Get("search")
	if search != "" {
		q = q.Like("name", search)
	}
	status := r.URL.Query().Get("status")
	if status != "" {
		q = q.Eq("status", status)
	} else {
		q = q.Eq("status", "approved")
	}

	// Sort
	sort := r.URL.Query().Get("sort")
	switch sort {
	case "price_asc":
		q = q.Order("price", true)
	case "price_desc":
		q = q.Order("price", false)
	case "sales":
		q = q.Order("sales", false)
	case "rating":
		q = q.Order("rating", false)
	default:
		q = q.Order("created_at", false)
	}

	// Pagination
	page := getQueryInt(r, "page", 1)
	limit := getQueryInt(r, "limit", 20)
	offset := (page - 1) * limit
	q = q.Limit(limit).Offset(offset)

	data, _, err := q.Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var products []map[string]interface{}
	json.Unmarshal(data, &products)
	if products == nil {
		products = []map[string]interface{}{}
	}

	// Add seller_name from joined profiles
	for i, p := range products {
		if prof, ok := p["profiles"].(map[string]interface{}); ok {
			products[i]["seller_name"] = prof["name"]
		}
		delete(products[i], "profiles")
	}

	writeJSON(w, http.StatusOK, models.PaginatedResponse{
		Success: true,
		Data:    products,
		Page:    page,
		Limit:   limit,
	})
}

func (h *ProductHandler) Get(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "缺少商品ID"})
		return
	}

	data, _, err := h.SB.From("products").Select("*,profiles!products_seller_id_fkey(name)").Eq("id", id).Single().Execute()
	if err != nil {
		writeJSON(w, http.StatusNotFound, models.APIResponse{Success: false, Message: "商品不存在"})
		return
	}

	var product map[string]interface{}
	json.Unmarshal(data, &product)
	if prof, ok := product["profiles"].(map[string]interface{}); ok {
		product["seller_name"] = prof["name"]
	}
	delete(product, "profiles")

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: product})
}

func (h *ProductHandler) Create(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)
	req["seller_id"] = userID
	req["status"] = "pending"

	data, _, err := h.SB.From("products").Insert(req).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "创建失败: " + err.Error()})
		return
	}

	var result []map[string]interface{}
	json.Unmarshal(data, &result)
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "商品已提交审核", Data: result})
}

func (h *ProductHandler) Update(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	id := r.URL.Query().Get("id")

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)
	delete(req, "id")
	delete(req, "seller_id")

	data, _, err := h.SB.From("products").Update(req).Eq("id", id).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "更新失败: " + err.Error()})
		return
	}

	var result []map[string]interface{}
	json.Unmarshal(data, &result)
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: result})
}

func (h *ProductHandler) Delete(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	id := r.URL.Query().Get("id")

	_, _, err := h.SB.From("products").Delete().Eq("id", id).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "删除失败"})
		return
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "删除成功"})
}

func (h *ProductHandler) SellerProducts(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	page := getQueryInt(r, "page", 1)
	limit := getQueryInt(r, "limit", 20)
	offset := (page - 1) * limit

	data, _, err := h.SB.From("products").Select("*").Eq("seller_id", userID).
		Order("created_at", false).Limit(limit).Offset(offset).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var products []map[string]interface{}
	json.Unmarshal(data, &products)
	if products == nil {
		products = []map[string]interface{}{}
	}

	writeJSON(w, http.StatusOK, models.PaginatedResponse{Success: true, Data: products, Page: page, Limit: limit})
}

func (h *ProductHandler) GetCategories(w http.ResponseWriter, r *http.Request) {
	data, _, err := h.SB.From("categories").Select("*").Order("sort_order", true).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var cats []map[string]interface{}
	json.Unmarshal(data, &cats)
	if cats == nil {
		cats = []map[string]interface{}{}
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: cats})
}

// ========== Reviews ==========

func (h *ProductHandler) GetReviews(w http.ResponseWriter, r *http.Request) {
	productID := r.URL.Query().Get("product_id")

	q := h.SB.From("reviews").Select("*,profiles!reviews_user_id_fkey(name,avatar)")
	if productID != "" {
		q = q.Eq("product_id", productID)
	}
	q = q.Eq("status", "approved").Order("created_at", false)

	page := getQueryInt(r, "page", 1)
	limit := getQueryInt(r, "limit", 10)
	q = q.Limit(limit).Offset((page - 1) * limit)

	data, _, err := q.Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var reviews []map[string]interface{}
	json.Unmarshal(data, &reviews)
	if reviews == nil {
		reviews = []map[string]interface{}{}
	}
	for i, rv := range reviews {
		if prof, ok := rv["profiles"].(map[string]interface{}); ok {
			reviews[i]["user_name"] = prof["name"]
			reviews[i]["user_avatar"] = prof["avatar"]
		}
		delete(reviews[i], "profiles")
	}

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: reviews})
}

func (h *ProductHandler) CreateReview(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)
	req["user_id"] = userID
	req["status"] = "approved"

	data, _, err := h.SB.From("reviews").Insert(req).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "评价失败: " + err.Error()})
		return
	}

	// Update product rating
	productID, _ := req["product_id"].(string)
	rating, _ := req["rating"].(float64)
	if productID != "" && rating > 0 {
		h.updateProductRating(productID, int(rating), token)
	}

	var result []map[string]interface{}
	json.Unmarshal(data, &result)
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "评价成功", Data: result})
}

func (h *ProductHandler) updateProductRating(productID string, newRating int, token string) {
	data, _, err := h.SB.From("products").Select("rating,rating_count").Eq("id", productID).Single().Execute()
	if err != nil {
		return
	}
	var p map[string]interface{}
	json.Unmarshal(data, &p)

	oldRating, _ := p["rating"].(float64)
	oldCount, _ := p["rating_count"].(float64)
	count := int(oldCount)
	newAvg := (oldRating*float64(count) + float64(newRating)) / float64(count+1)

	h.SB.From("products").Update(map[string]interface{}{
		"rating":       strconv.FormatFloat(newAvg, 'f', 1, 64),
		"rating_count": count + 1,
	}).Eq("id", productID).AsService().Execute()
}
