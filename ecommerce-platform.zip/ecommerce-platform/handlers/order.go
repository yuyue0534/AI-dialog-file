package handlers

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"time"

	"ecommerce-platform/middleware"
	"ecommerce-platform/models"
	"ecommerce-platform/supabase"
)

type OrderHandler struct {
	SB *supabase.Client
}

func generateOrderNo() string {
	now := time.Now()
	return fmt.Sprintf("ORD%s%06d", now.Format("20060102"), rand.Intn(1000000))
}

func (h *OrderHandler) CreateOrder(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	var req struct {
		AddressID     string   `json:"address_id"`
		PaymentMethod string   `json:"payment_method"`
		Remark        string   `json:"remark"`
		CartItemIDs   []string `json:"cart_item_ids"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if req.AddressID == "" {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "请选择收货地址"})
		return
	}

	// Get address
	addrData, _, err := h.SB.From("addresses").Select("*").Eq("id", req.AddressID).Auth(token).Single().Execute()
	if err != nil {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "地址不存在"})
		return
	}
	var addr map[string]interface{}
	json.Unmarshal(addrData, &addr)

	// Get cart items
	q := h.SB.From("cart_items").Select("*,products(id,name,price,images,stock,seller_id)").Eq("user_id", userID).Eq("selected", "true").Auth(token)
	cartData, _, err := q.Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "获取购物车失败"})
		return
	}

	var cartItems []map[string]interface{}
	json.Unmarshal(cartData, &cartItems)

	if len(cartItems) == 0 {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "购物车为空"})
		return
	}

	// Calculate total and prepare order items
	var totalAmount float64
	var orderItems []map[string]interface{}

	for _, item := range cartItems {
		prod, _ := item["products"].(map[string]interface{})
		price, _ := prod["price"].(float64)
		qty, _ := item["quantity"].(float64)
		stock, _ := prod["stock"].(float64)

		if int(qty) > int(stock) {
			name, _ := prod["name"].(string)
			writeJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false, Message: fmt.Sprintf("商品 %s 库存不足", name),
			})
			return
		}

		totalAmount += price * qty

		// Extract first image
		prodImage := ""
		if images, ok := prod["images"].(string); ok && images != "" && images != "[]" {
			var imgArr []string
			json.Unmarshal([]byte(images), &imgArr)
			if len(imgArr) > 0 {
				prodImage = imgArr[0]
			}
		}

		orderItems = append(orderItems, map[string]interface{}{
			"product_id":    prod["id"],
			"product_name":  prod["name"],
			"product_image": prodImage,
			"price":         price,
			"quantity":      int(qty),
			"seller_id":     prod["seller_id"],
		})
	}

	// Create order
	shipAddr := fmt.Sprintf("%v%v%v%v", addr["province"], addr["city"], addr["district"], addr["detail"])
	orderNo := generateOrderNo()

	orderData, _, err := h.SB.From("orders").Insert(map[string]interface{}{
		"order_no":       orderNo,
		"user_id":        userID,
		"total_amount":   totalAmount,
		"status":         "pending_payment",
		"payment_method": req.PaymentMethod,
		"ship_name":      addr["name"],
		"ship_phone":     addr["phone"],
		"ship_address":   shipAddr,
		"remark":         req.Remark,
	}).Auth(token).Execute()

	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "创建订单失败: " + err.Error()})
		return
	}

	var orders []map[string]interface{}
	json.Unmarshal(orderData, &orders)
	if len(orders) == 0 {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "创建订单失败"})
		return
	}
	orderID := orders[0]["id"].(string)

	// Create order items
	for i := range orderItems {
		orderItems[i]["order_id"] = orderID
	}
	_, _, err = h.SB.From("order_items").Insert(orderItems).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "创建订单项失败"})
		return
	}

	// Deduct stock (using service key to bypass RLS)
	for _, item := range cartItems {
		prod, _ := item["products"].(map[string]interface{})
		productID, _ := prod["id"].(string)
		stock, _ := prod["stock"].(float64)
		qty, _ := item["quantity"].(float64)
		newStock := int(stock) - int(qty)

		h.SB.From("products").Update(map[string]interface{}{
			"stock": newStock,
			"sales": fmt.Sprintf("sales + %d", int(qty)),
		}).Eq("id", productID).AsService().Execute()
	}

	// Clear selected cart items
	h.SB.From("cart_items").Delete().Eq("user_id", userID).Eq("selected", "true").Auth(token).Execute()

	writeJSON(w, http.StatusOK, models.APIResponse{
		Success: true,
		Message: "订单创建成功",
		Data: map[string]interface{}{
			"order_id": orderID,
			"order_no": orderNo,
			"total":    totalAmount,
		},
	})
}

func (h *OrderHandler) GetOrders(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	q := h.SB.From("orders").Select("*").Eq("user_id", userID).Order("created_at", false)

	status := r.URL.Query().Get("status")
	if status != "" {
		q = q.Eq("status", status)
	}

	page := getQueryInt(r, "page", 1)
	limit := getQueryInt(r, "limit", 10)
	q = q.Limit(limit).Offset((page - 1) * limit)

	data, _, err := q.Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var orders []map[string]interface{}
	json.Unmarshal(data, &orders)
	if orders == nil {
		orders = []map[string]interface{}{}
	}

	// Fetch items for each order
	for i, order := range orders {
		orderID, _ := order["id"].(string)
		itemData, _, _ := h.SB.From("order_items").Select("*").Eq("order_id", orderID).Auth(token).Execute()
		var items []map[string]interface{}
		json.Unmarshal(itemData, &items)
		if items == nil {
			items = []map[string]interface{}{}
		}
		orders[i]["items"] = items
	}

	writeJSON(w, http.StatusOK, models.PaginatedResponse{Success: true, Data: orders, Page: page, Limit: limit})
}

func (h *OrderHandler) GetOrder(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	orderID := r.URL.Query().Get("id")

	data, _, err := h.SB.From("orders").Select("*").Eq("id", orderID).Auth(token).Single().Execute()
	if err != nil {
		writeJSON(w, http.StatusNotFound, models.APIResponse{Success: false, Message: "订单不存在"})
		return
	}

	var order map[string]interface{}
	json.Unmarshal(data, &order)

	// Get items
	itemData, _, _ := h.SB.From("order_items").Select("*").Eq("order_id", orderID).Auth(token).Execute()
	var items []map[string]interface{}
	json.Unmarshal(itemData, &items)
	if items == nil {
		items = []map[string]interface{}{}
	}
	order["items"] = items

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: order})
}

func (h *OrderHandler) PayOrder(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	orderID := r.URL.Query().Get("id")

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)

	payMethod, _ := req["payment_method"].(string)
	if payMethod == "" {
		payMethod = "online"
	}

	// Simulate payment success
	_, _, err := h.SB.From("orders").Update(map[string]interface{}{
		"status":         "pending_ship",
		"payment_method": payMethod,
		"updated_at":     time.Now().Format(time.RFC3339),
	}).Eq("id", orderID).Eq("status", "pending_payment").Auth(token).Execute()

	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "支付失败"})
		return
	}

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "支付成功"})
}

func (h *OrderHandler) CancelOrder(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	orderID := r.URL.Query().Get("id")

	_, _, err := h.SB.From("orders").Update(map[string]interface{}{
		"status":     "cancelled",
		"updated_at": time.Now().Format(time.RFC3339),
	}).Eq("id", orderID).Auth(token).Execute()

	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "取消失败"})
		return
	}

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "订单已取消"})
}

func (h *OrderHandler) ConfirmReceive(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	orderID := r.URL.Query().Get("id")

	_, _, err := h.SB.From("orders").Update(map[string]interface{}{
		"status":     "completed",
		"updated_at": time.Now().Format(time.RFC3339),
	}).Eq("id", orderID).Eq("status", "shipped").Auth(token).Execute()

	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "确认失败"})
		return
	}

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "已确认收货"})
}

// ========== Seller order operations ==========

func (h *OrderHandler) SellerOrders(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	// Get order_ids from order_items where seller_id = userID
	itemData, _, err := h.SB.From("order_items").Select("order_id").Eq("seller_id", userID).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var items []map[string]interface{}
	json.Unmarshal(itemData, &items)

	orderIDSet := make(map[string]bool)
	var orderIDs []string
	for _, item := range items {
		oid, _ := item["order_id"].(string)
		if !orderIDSet[oid] {
			orderIDSet[oid] = true
			orderIDs = append(orderIDs, oid)
		}
	}

	if len(orderIDs) == 0 {
		writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: []interface{}{}})
		return
	}

	// Fetch orders using service key (seller needs to see buyer orders)
	data, _, err := h.SB.From("orders").Select("*").In("id", orderIDs).Order("created_at", false).AsService().Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var orders []map[string]interface{}
	json.Unmarshal(data, &orders)
	if orders == nil {
		orders = []map[string]interface{}{}
	}

	// Fetch items for each order
	for i, order := range orders {
		oid, _ := order["id"].(string)
		iData, _, _ := h.SB.From("order_items").Select("*").Eq("order_id", oid).Eq("seller_id", userID).Auth(token).Execute()
		var oi []map[string]interface{}
		json.Unmarshal(iData, &oi)
		if oi == nil {
			oi = []map[string]interface{}{}
		}
		orders[i]["items"] = oi
	}

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: orders})
}

func (h *OrderHandler) ShipOrder(w http.ResponseWriter, r *http.Request) {
	orderID := r.URL.Query().Get("id")

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)

	trackingNo, _ := req["tracking_no"].(string)

	_, _, err := h.SB.From("orders").Update(map[string]interface{}{
		"status":      "shipped",
		"tracking_no": trackingNo,
		"updated_at":  time.Now().Format(time.RFC3339),
	}).Eq("id", orderID).AsService().Execute()

	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "发货失败"})
		return
	}

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "已发货"})
}
