package handlers

import (
	"encoding/json"
	"net/http"

	"ecommerce-platform/middleware"
	"ecommerce-platform/models"
	"ecommerce-platform/supabase"
)

type CartHandler struct {
	SB *supabase.Client
}

func (h *CartHandler) GetCart(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	data, _, err := h.SB.From("cart_items").
		Select("*,products(name,price,images,stock,status)").
		Eq("user_id", userID).
		Order("created_at", false).
		Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: err.Error()})
		return
	}

	var items []map[string]interface{}
	json.Unmarshal(data, &items)
	if items == nil {
		items = []map[string]interface{}{}
	}

	// Flatten product info
	for i, item := range items {
		if prod, ok := item["products"].(map[string]interface{}); ok {
			items[i]["product_name"] = prod["name"]
			items[i]["price"] = prod["price"]
			items[i]["product_stock"] = prod["stock"]
			images, _ := prod["images"].(string)
			if images != "" && images != "[]" {
				var imgArr []string
				json.Unmarshal([]byte(images), &imgArr)
				if len(imgArr) > 0 {
					items[i]["product_image"] = imgArr[0]
				}
			}
		}
		delete(items[i], "products")
	}

	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Data: items})
}

func (h *CartHandler) AddToCart(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	var req models.CartAddRequest
	json.NewDecoder(r.Body).Decode(&req)

	if req.ProductID == "" || req.Quantity <= 0 {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "无效的参数"})
		return
	}

	// Check stock
	prodData, _, err := h.SB.From("products").Select("stock,status").Eq("id", req.ProductID).Single().Execute()
	if err != nil {
		writeJSON(w, http.StatusNotFound, models.APIResponse{Success: false, Message: "商品不存在"})
		return
	}
	var prod map[string]interface{}
	json.Unmarshal(prodData, &prod)
	stock, _ := prod["stock"].(float64)
	status, _ := prod["status"].(string)
	if status != "approved" {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "商品不可购买"})
		return
	}
	if int(stock) < req.Quantity {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "库存不足"})
		return
	}

	// Upsert cart item
	data, _, err := h.SB.From("cart_items").Upsert(map[string]interface{}{
		"user_id":    userID,
		"product_id": req.ProductID,
		"quantity":   req.Quantity,
		"selected":   true,
	}).Auth(token).Execute()

	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "添加失败: " + err.Error()})
		return
	}

	var result []map[string]interface{}
	json.Unmarshal(data, &result)
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "已添加到购物车", Data: result})
}

func (h *CartHandler) UpdateCartItem(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	itemID := r.URL.Query().Get("id")

	var req map[string]interface{}
	json.NewDecoder(r.Body).Decode(&req)

	// Only allow quantity and selected
	update := make(map[string]interface{})
	if q, ok := req["quantity"]; ok {
		update["quantity"] = q
	}
	if s, ok := req["selected"]; ok {
		update["selected"] = s
	}

	_, _, err := h.SB.From("cart_items").Update(update).Eq("id", itemID).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "更新失败"})
		return
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "更新成功"})
}

func (h *CartHandler) RemoveCartItem(w http.ResponseWriter, r *http.Request) {
	token := middleware.GetUserToken(r)
	itemID := r.URL.Query().Get("id")

	_, _, err := h.SB.From("cart_items").Delete().Eq("id", itemID).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "删除失败"})
		return
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "已移除"})
}

func (h *CartHandler) ClearCart(w http.ResponseWriter, r *http.Request) {
	userID := middleware.GetUserID(r)
	token := middleware.GetUserToken(r)

	_, _, err := h.SB.From("cart_items").Delete().Eq("user_id", userID).Auth(token).Execute()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "清空失败"})
		return
	}
	writeJSON(w, http.StatusOK, models.APIResponse{Success: true, Message: "购物车已清空"})
}
