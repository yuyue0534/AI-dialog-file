package repository

import (
	"context"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/yourorg/emp-api/internal/model"
)

type SalaryRepo struct {
	db *pgxpool.Pool
}

func NewSalaryRepo(db *pgxpool.Pool) *SalaryRepo {
	return &SalaryRepo{db: db}
}

func (r *SalaryRepo) ListByEmployee(ctx context.Context, empNo int) ([]*model.Salary, error) {
	rows, err := r.db.Query(ctx,
		`SELECT emp_no, amount, from_date, to_date
		 FROM emp_salary WHERE emp_no = $1
		 ORDER BY from_date DESC`, empNo,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []*model.Salary
	for rows.Next() {
		s := &model.Salary{}
		if err := rows.Scan(&s.EmpNo, &s.Amount, &s.FromDate, &s.ToDate); err != nil {
			return nil, err
		}
		list = append(list, s)
	}
	return list, rows.Err()
}

func (r *SalaryRepo) Create(ctx context.Context, empNo int, req *model.CreateSalaryReq) error {
	_, err := r.db.Exec(ctx,
		`INSERT INTO emp_salary (emp_no, amount, from_date, to_date)
		 VALUES ($1,$2,$3,$4)`,
		empNo, req.Amount, req.FromDate, req.ToDate,
	)
	return err
}

// UpdateCurrent updates the amount of the employee's active salary record.
func (r *SalaryRepo) UpdateCurrent(ctx context.Context, empNo, amount int) error {
	_, err := r.db.Exec(ctx,
		`UPDATE emp_salary SET amount = $1
		 WHERE emp_no = $2 AND to_date = '9999-01-01'`,
		amount, empNo,
	)
	return err
}

func (r *SalaryRepo) Delete(ctx context.Context, empNo int, fromDate string) error {
	_, err := r.db.Exec(ctx,
		"DELETE FROM emp_salary WHERE emp_no = $1 AND from_date = $2",
		empNo, fromDate,
	)
	return err
}
