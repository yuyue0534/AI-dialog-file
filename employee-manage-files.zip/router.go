package handler

import (
	"github.com/gin-gonic/gin"
	"github.com/yourorg/emp-api/internal/middleware"
)

type Router struct {
	employee   *EmployeeHandler
	department *DepartmentHandler
	salary     *SalaryHandler
	title      *TitleHandler
}

func NewRouter(
	employee *EmployeeHandler,
	department *DepartmentHandler,
	salary *SalaryHandler,
	title *TitleHandler,
) *Router {
	return &Router{employee, department, salary, title}
}

func (r *Router) Setup(engine *gin.Engine) {
	engine.Use(middleware.Logger(), middleware.Recovery())

	// Health check
	engine.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	v1 := engine.Group("/api/v1")

	// Employees
	emp := v1.Group("/employees")
	{
		emp.GET("", r.employee.List)
		emp.POST("", r.employee.Create)
		emp.GET("/:id", r.employee.Get)
		emp.PATCH("/:id", r.employee.Update)
		emp.DELETE("/:id", r.employee.Delete)

		// Salaries (nested under employee)
		emp.GET("/:id/salaries", r.salary.List)
		emp.POST("/:id/salaries", r.salary.Create)
		emp.PATCH("/:id/salaries/current", r.salary.UpdateCurrent)
		emp.DELETE("/:id/salaries/:from_date", r.salary.Delete)

		// Titles (nested under employee)
		emp.GET("/:id/titles", r.title.List)
		emp.POST("/:id/titles", r.title.Create)
		emp.DELETE("/:id/titles/:title/:from_date", r.title.Delete)
	}

	// Departments
	dept := v1.Group("/departments")
	{
		dept.GET("", r.department.List)
		dept.POST("", r.department.Create)
		dept.GET("/:id", r.department.Get)
		dept.PATCH("/:id", r.department.Update)
		dept.DELETE("/:id", r.department.Delete)
		dept.GET("/:id/employees", r.department.ListEmployees)
		dept.GET("/:id/manager", r.department.GetManager)
		dept.PUT("/:id/manager", r.department.AssignManager)
	}
}
