package middleware

import (
	"log"
	"time"

	"github.com/gin-gonic/gin"
)

// Logger prints method, path, status, latency for every request.
func Logger() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		c.Next()
		log.Printf("[%s] %s %d %s",
			c.Request.Method,
			c.Request.URL.Path,
			c.Writer.Status(),
			time.Since(start),
		)
	}
}

// Recovery catches panics and returns 500.
func Recovery() gin.HandlerFunc {
	return gin.Recovery()
}
