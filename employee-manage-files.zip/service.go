package service

import (
	"context"
	"errors"
	"time"

	"github.com/yourorg/emp-api/internal/model"
	"github.com/yourorg/emp-api/internal/repository"
)

// ─── Employee Service ────────────────────────────────────────

type EmployeeService struct {
	repo *repository.EmployeeRepo
}

func NewEmployeeService(r *repository.EmployeeRepo) *EmployeeService {
	return &EmployeeService{repo: r}
}

func (s *EmployeeService) List(ctx context.Context, page, size int, gender, name string) ([]*model.Employee, int64, error) {
	if page < 1 {
		page = 1
	}
	if size < 1 || size > 100 {
		size = 20
	}
	return s.repo.List(ctx, page, size, gender, name)
}

func (s *EmployeeService) GetDetail(ctx context.Context, empNo int) (*model.EmployeeDetail, error) {
	return s.repo.GetDetail(ctx, empNo)
}

func (s *EmployeeService) Create(ctx context.Context, req *model.CreateEmployeeReq) (int, error) {
	birth, err := time.Parse("2006-01-02", req.BirthDate)
	if err != nil {
		return 0, errors.New("birth_date must be YYYY-MM-DD")
	}
	hire, err := time.Parse("2006-01-02", req.HireDate)
	if err != nil {
		return 0, errors.New("hire_date must be YYYY-MM-DD")
	}
	e := &model.Employee{
		BirthDate: birth,
		FirstName: req.FirstName,
		LastName:  req.LastName,
		Gender:    req.Gender,
		HireDate:  hire,
	}
	return s.repo.Create(ctx, e)
}

func (s *EmployeeService) Update(ctx context.Context, empNo int, req *model.UpdateEmployeeReq) error {
	existing, err := s.repo.GetByID(ctx, empNo)
	if err != nil {
		return err
	}
	if existing == nil {
		return errors.New("not found")
	}

	fields := map[string]any{}
	if req.FirstName != "" {
		fields["first_name"] = req.FirstName
	}
	if req.LastName != "" {
		fields["last_name"] = req.LastName
	}
	if req.Gender != "" {
		fields["gender"] = req.Gender
	}
	if req.BirthDate != "" {
		t, err := time.Parse("2006-01-02", req.BirthDate)
		if err != nil {
			return errors.New("birth_date must be YYYY-MM-DD")
		}
		fields["birth_date"] = t
	}
	if req.HireDate != "" {
		t, err := time.Parse("2006-01-02", req.HireDate)
		if err != nil {
			return errors.New("hire_date must be YYYY-MM-DD")
		}
		fields["hire_date"] = t
	}
	return s.repo.Update(ctx, empNo, fields)
}

func (s *EmployeeService) Delete(ctx context.Context, empNo int) error {
	existing, err := s.repo.GetByID(ctx, empNo)
	if err != nil {
		return err
	}
	if existing == nil {
		return errors.New("not found")
	}
	return s.repo.Delete(ctx, empNo)
}

// ─── Department Service ──────────────────────────────────────

type DepartmentService struct {
	repo *repository.DepartmentRepo
}

func NewDepartmentService(r *repository.DepartmentRepo) *DepartmentService {
	return &DepartmentService{repo: r}
}

func (s *DepartmentService) List(ctx context.Context) ([]*model.Department, error) {
	return s.repo.List(ctx)
}

func (s *DepartmentService) Get(ctx context.Context, deptNo string) (*model.Department, error) {
	return s.repo.GetByID(ctx, deptNo)
}

func (s *DepartmentService) Create(ctx context.Context, req *model.CreateDepartmentReq) error {
	existing, _ := s.repo.GetByID(ctx, req.DeptNo)
	if existing != nil {
		return errors.New("dept_no already exists")
	}
	return s.repo.Create(ctx, &model.Department{DeptNo: req.DeptNo, DeptName: req.DeptName})
}

func (s *DepartmentService) Update(ctx context.Context, deptNo string, req *model.UpdateDepartmentReq) error {
	return s.repo.Update(ctx, deptNo, req.DeptName)
}

func (s *DepartmentService) Delete(ctx context.Context, deptNo string) error {
	return s.repo.Delete(ctx, deptNo)
}

func (s *DepartmentService) ListEmployees(ctx context.Context, deptNo string) ([]*model.Employee, error) {
	return s.repo.ListEmployees(ctx, deptNo)
}

func (s *DepartmentService) GetManager(ctx context.Context, deptNo string) (*model.Employee, error) {
	return s.repo.GetManager(ctx, deptNo)
}

func (s *DepartmentService) AssignManager(ctx context.Context, deptNo string, req *model.AssignManagerReq) error {
	return s.repo.AssignManager(ctx, deptNo, req)
}

// ─── Salary Service ──────────────────────────────────────────

type SalaryService struct {
	repo *repository.SalaryRepo
}

func NewSalaryService(r *repository.SalaryRepo) *SalaryService {
	return &SalaryService{repo: r}
}

func (s *SalaryService) List(ctx context.Context, empNo int) ([]*model.Salary, error) {
	return s.repo.ListByEmployee(ctx, empNo)
}

func (s *SalaryService) Create(ctx context.Context, empNo int, req *model.CreateSalaryReq) error {
	return s.repo.Create(ctx, empNo, req)
}

func (s *SalaryService) UpdateCurrent(ctx context.Context, empNo int, req *model.UpdateSalaryReq) error {
	return s.repo.UpdateCurrent(ctx, empNo, req.Amount)
}

func (s *SalaryService) Delete(ctx context.Context, empNo int, fromDate string) error {
	return s.repo.Delete(ctx, empNo, fromDate)
}

// ─── Title Service ───────────────────────────────────────────

type TitleService struct {
	repo *repository.TitleRepo
}

func NewTitleService(r *repository.TitleRepo) *TitleService {
	return &TitleService{repo: r}
}

func (s *TitleService) List(ctx context.Context, empNo int) ([]*model.Title, error) {
	return s.repo.ListByEmployee(ctx, empNo)
}

func (s *TitleService) Create(ctx context.Context, empNo int, req *model.AssignTitleReq) error {
	return s.repo.Create(ctx, empNo, req)
}

func (s *TitleService) Delete(ctx context.Context, empNo int, title, fromDate string) error {
	return s.repo.Delete(ctx, empNo, title, fromDate)
}
