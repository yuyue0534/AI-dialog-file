package handler

import (
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/emp-api/internal/model"
	"github.com/yourorg/emp-api/internal/service"
	"github.com/yourorg/emp-api/pkg/response"
)

type TitleHandler struct {
	svc *service.TitleService
}

func NewTitleHandler(svc *service.TitleService) *TitleHandler {
	return &TitleHandler{svc: svc}
}

// GET /api/v1/employees/:id/titles
func (h *TitleHandler) List(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	list, err := h.svc.List(c.Request.Context(), empNo)
	if err != nil {
		response.InternalError(c, err.Error())
		return
	}
	if list == nil {
		list = []*model.Title{}
	}
	response.OK(c, list)
}

// POST /api/v1/employees/:id/titles
func (h *TitleHandler) Create(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	var req model.AssignTitleReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.svc.Create(c.Request.Context(), empNo, &req); err != nil {
		response.InternalError(c, err.Error())
		return
	}
	response.Created(c, gin.H{"created": true})
}

// DELETE /api/v1/employees/:id/titles/:title/:from_date
func (h *TitleHandler) Delete(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	title := c.Param("title")
	fromDate := c.Param("from_date")
	if err := h.svc.Delete(c.Request.Context(), empNo, title, fromDate); err != nil {
		response.InternalError(c, err.Error())
		return
	}
	response.OK(c, gin.H{"deleted": true})
}
