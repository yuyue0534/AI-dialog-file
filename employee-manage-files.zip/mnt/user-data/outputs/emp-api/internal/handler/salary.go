package handler

import (
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/emp-api/internal/model"
	"github.com/yourorg/emp-api/internal/service"
	"github.com/yourorg/emp-api/pkg/response"
)

type SalaryHandler struct {
	svc *service.SalaryService
}

func NewSalaryHandler(svc *service.SalaryService) *SalaryHandler {
	return &SalaryHandler{svc: svc}
}

// GET /api/v1/employees/:id/salaries
func (h *SalaryHandler) List(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	list, err := h.svc.List(c.Request.Context(), empNo)
	if err != nil {
		response.InternalError(c, err.Error())
		return
	}
	if list == nil {
		list = []*model.Salary{}
	}
	response.OK(c, list)
}

// POST /api/v1/employees/:id/salaries
func (h *SalaryHandler) Create(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	var req model.CreateSalaryReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.svc.Create(c.Request.Context(), empNo, &req); err != nil {
		response.InternalError(c, err.Error())
		return
	}
	response.Created(c, gin.H{"created": true})
}

// PATCH /api/v1/employees/:id/salaries/current
func (h *SalaryHandler) UpdateCurrent(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	var req model.UpdateSalaryReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.svc.UpdateCurrent(c.Request.Context(), empNo, &req); err != nil {
		response.InternalError(c, err.Error())
		return
	}
	response.OK(c, gin.H{"updated": true})
}

// DELETE /api/v1/employees/:id/salaries/:from_date
func (h *SalaryHandler) Delete(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	fromDate := c.Param("from_date")
	if err := h.svc.Delete(c.Request.Context(), empNo, fromDate); err != nil {
		response.InternalError(c, err.Error())
		return
	}
	response.OK(c, gin.H{"deleted": true})
}
