package handler

import (
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/emp-api/internal/model"
	"github.com/yourorg/emp-api/internal/service"
	"github.com/yourorg/emp-api/pkg/response"
)

type EmployeeHandler struct {
	svc *service.EmployeeService
}

func NewEmployeeHandler(svc *service.EmployeeService) *EmployeeHandler {
	return &EmployeeHandler{svc: svc}
}

// GET /api/v1/employees?page=1&size=20&gender=M&name=john
func (h *EmployeeHandler) List(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	size, _ := strconv.Atoi(c.DefaultQuery("size", "20"))
	gender := c.Query("gender")
	name := c.Query("name")

	list, total, err := h.svc.List(c.Request.Context(), page, size, gender, name)
	if err != nil {
		response.InternalError(c, err.Error())
		return
	}
	if list == nil {
		list = []*model.Employee{}
	}
	response.OKPaged(c, list, total, page, size)
}

// GET /api/v1/employees/:id
func (h *EmployeeHandler) Get(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	detail, err := h.svc.GetDetail(c.Request.Context(), empNo)
	if err != nil {
		response.InternalError(c, err.Error())
		return
	}
	if detail == nil {
		response.NotFound(c, "employee not found")
		return
	}
	response.OK(c, detail)
}

// POST /api/v1/employees
func (h *EmployeeHandler) Create(c *gin.Context) {
	var req model.CreateEmployeeReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	id, err := h.svc.Create(c.Request.Context(), &req)
	if err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	response.Created(c, gin.H{"emp_no": id})
}

// PATCH /api/v1/employees/:id
func (h *EmployeeHandler) Update(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	var req model.UpdateEmployeeReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.svc.Update(c.Request.Context(), empNo, &req); err != nil {
		if err.Error() == "not found" {
			response.NotFound(c, "employee not found")
		} else {
			response.BadRequest(c, err.Error())
		}
		return
	}
	response.OK(c, gin.H{"updated": true})
}

// DELETE /api/v1/employees/:id
func (h *EmployeeHandler) Delete(c *gin.Context) {
	empNo, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		response.BadRequest(c, "invalid employee id")
		return
	}
	if err := h.svc.Delete(c.Request.Context(), empNo); err != nil {
		if err.Error() == "not found" {
			response.NotFound(c, "employee not found")
		} else {
			response.InternalError(c, err.Error())
		}
		return
	}
	response.OK(c, gin.H{"deleted": true})
}
