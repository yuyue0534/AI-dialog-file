package handler

import (
	"github.com/gin-gonic/gin"
	"github.com/yourorg/emp-api/internal/model"
	"github.com/yourorg/emp-api/internal/service"
	"github.com/yourorg/emp-api/pkg/response"
)

type DepartmentHandler struct {
	svc *service.DepartmentService
}

func NewDepartmentHandler(svc *service.DepartmentService) *DepartmentHandler {
	return &DepartmentHandler{svc: svc}
}

// GET /api/v1/departments
func (h *DepartmentHandler) List(c *gin.Context) {
	list, err := h.svc.List(c.Request.Context())
	if err != nil {
		response.InternalError(c, err.Error())
		return
	}
	if list == nil {
		list = []*model.Department{}
	}
	response.OK(c, list)
}

// GET /api/v1/departments/:id
func (h *DepartmentHandler) Get(c *gin.Context) {
	d, err := h.svc.Get(c.Request.Context(), c.Param("id"))
	if err != nil {
		response.InternalError(c, err.Error())
		return
	}
	if d == nil {
		response.NotFound(c, "department not found")
		return
	}
	response.OK(c, d)
}

// POST /api/v1/departments
func (h *DepartmentHandler) Create(c *gin.Context) {
	var req model.CreateDepartmentReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.svc.Create(c.Request.Context(), &req); err != nil {
		response.Conflict(c, err.Error())
		return
	}
	response.Created(c, gin.H{"dept_no": req.DeptNo})
}

// PATCH /api/v1/departments/:id
func (h *DepartmentHandler) Update(c *gin.Context) {
	var req model.UpdateDepartmentReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.svc.Update(c.Request.Context(), c.Param("id"), &req); err != nil {
		response.InternalError(c, err.Error())
		return
	}
	response.OK(c, gin.H{"updated": true})
}

// DELETE /api/v1/departments/:id
func (h *DepartmentHandler) Delete(c *gin.Context) {
	if err := h.svc.Delete(c.Request.Context(), c.Param("id")); err != nil {
		response.InternalError(c, err.Error())
		return
	}
	response.OK(c, gin.H{"deleted": true})
}

// GET /api/v1/departments/:id/employees
func (h *DepartmentHandler) ListEmployees(c *gin.Context) {
	list, err := h.svc.ListEmployees(c.Request.Context(), c.Param("id"))
	if err != nil {
		response.InternalError(c, err.Error())
		return
	}
	if list == nil {
		list = []*model.Employee{}
	}
	response.OK(c, list)
}

// GET /api/v1/departments/:id/manager
func (h *DepartmentHandler) GetManager(c *gin.Context) {
	mgr, err := h.svc.GetManager(c.Request.Context(), c.Param("id"))
	if err != nil {
		response.InternalError(c, err.Error())
		return
	}
	if mgr == nil {
		response.NotFound(c, "no current manager")
		return
	}
	response.OK(c, mgr)
}

// PUT /api/v1/departments/:id/manager
func (h *DepartmentHandler) AssignManager(c *gin.Context) {
	var req model.AssignManagerReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.svc.AssignManager(c.Request.Context(), c.Param("id"), &req); err != nil {
		response.InternalError(c, err.Error())
		return
	}
	response.OK(c, gin.H{"assigned": true})
}
