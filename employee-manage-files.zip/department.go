package repository

import (
	"context"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/yourorg/emp-api/internal/model"
)

type DepartmentRepo struct {
	db *pgxpool.Pool
}

func NewDepartmentRepo(db *pgxpool.Pool) *DepartmentRepo {
	return &DepartmentRepo{db: db}
}

func (r *DepartmentRepo) List(ctx context.Context) ([]*model.Department, error) {
	rows, err := r.db.Query(ctx, "SELECT dept_no, dept_name FROM emp_department ORDER BY dept_no")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []*model.Department
	for rows.Next() {
		d := &model.Department{}
		if err := rows.Scan(&d.DeptNo, &d.DeptName); err != nil {
			return nil, err
		}
		list = append(list, d)
	}
	return list, rows.Err()
}

func (r *DepartmentRepo) GetByID(ctx context.Context, deptNo string) (*model.Department, error) {
	d := &model.Department{}
	err := r.db.QueryRow(ctx,
		"SELECT dept_no, dept_name FROM emp_department WHERE dept_no = $1", deptNo,
	).Scan(&d.DeptNo, &d.DeptName)
	if err == pgx.ErrNoRows {
		return nil, nil
	}
	return d, err
}

func (r *DepartmentRepo) Create(ctx context.Context, d *model.Department) error {
	_, err := r.db.Exec(ctx,
		"INSERT INTO emp_department (dept_no, dept_name) VALUES ($1,$2)",
		d.DeptNo, d.DeptName,
	)
	return err
}

func (r *DepartmentRepo) Update(ctx context.Context, deptNo, deptName string) error {
	_, err := r.db.Exec(ctx,
		"UPDATE emp_department SET dept_name = $1 WHERE dept_no = $2",
		deptName, deptNo,
	)
	return err
}

func (r *DepartmentRepo) Delete(ctx context.Context, deptNo string) error {
	_, err := r.db.Exec(ctx, "DELETE FROM emp_department WHERE dept_no = $1", deptNo)
	return err
}

// ListEmployees returns employees currently in this department.
func (r *DepartmentRepo) ListEmployees(ctx context.Context, deptNo string) ([]*model.Employee, error) {
	rows, err := r.db.Query(ctx,
		`SELECT e.emp_no, e.birth_date, e.first_name, e.last_name, e.gender, e.hire_date
		 FROM emp_employee e
		 JOIN emp_dept_emp de ON de.emp_no = e.emp_no
		 WHERE de.dept_no = $1 AND de.to_date = '9999-01-01'
		 ORDER BY e.emp_no`, deptNo,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []*model.Employee
	for rows.Next() {
		e := &model.Employee{}
		if err := rows.Scan(&e.EmpNo, &e.BirthDate, &e.FirstName, &e.LastName, &e.Gender, &e.HireDate); err != nil {
			return nil, err
		}
		list = append(list, e)
	}
	return list, rows.Err()
}

// GetManager returns the current manager of a department.
func (r *DepartmentRepo) GetManager(ctx context.Context, deptNo string) (*model.Employee, error) {
	e := &model.Employee{}
	err := r.db.QueryRow(ctx,
		`SELECT e.emp_no, e.birth_date, e.first_name, e.last_name, e.gender, e.hire_date
		 FROM emp_employee e
		 JOIN emp_dept_manager dm ON dm.emp_no = e.emp_no
		 WHERE dm.dept_no = $1 AND dm.to_date = '9999-01-01'
		 LIMIT 1`, deptNo,
	).Scan(&e.EmpNo, &e.BirthDate, &e.FirstName, &e.LastName, &e.Gender, &e.HireDate)
	if err == pgx.ErrNoRows {
		return nil, nil
	}
	return e, err
}

func (r *DepartmentRepo) AssignManager(ctx context.Context, deptNo string, req *model.AssignManagerReq) error {
	_, err := r.db.Exec(ctx,
		`INSERT INTO emp_dept_manager (emp_no, dept_no, from_date, to_date)
		 VALUES ($1,$2,$3,$4)
		 ON CONFLICT (emp_no, dept_no) DO UPDATE
		 SET from_date = EXCLUDED.from_date, to_date = EXCLUDED.to_date`,
		req.EmpNo, deptNo, req.FromDate, req.ToDate,
	)
	return err
}
