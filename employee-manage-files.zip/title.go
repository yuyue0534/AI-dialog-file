package repository

import (
	"context"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/yourorg/emp-api/internal/model"
)

type TitleRepo struct {
	db *pgxpool.Pool
}

func NewTitleRepo(db *pgxpool.Pool) *TitleRepo {
	return &TitleRepo{db: db}
}

func (r *TitleRepo) ListByEmployee(ctx context.Context, empNo int) ([]*model.Title, error) {
	rows, err := r.db.Query(ctx,
		`SELECT emp_no, title, from_date, to_date
		 FROM emp_title WHERE emp_no = $1
		 ORDER BY from_date DESC`, empNo,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []*model.Title
	for rows.Next() {
		t := &model.Title{}
		if err := rows.Scan(&t.EmpNo, &t.Title, &t.FromDate, &t.ToDate); err != nil {
			return nil, err
		}
		list = append(list, t)
	}
	return list, rows.Err()
}

func (r *TitleRepo) Create(ctx context.Context, empNo int, req *model.AssignTitleReq) error {
	var toDate *string
	if req.ToDate != "" {
		toDate = &req.ToDate
	}
	_, err := r.db.Exec(ctx,
		`INSERT INTO emp_title (emp_no, title, from_date, to_date)
		 VALUES ($1,$2,$3,$4)`,
		empNo, req.Title, req.FromDate, toDate,
	)
	return err
}

func (r *TitleRepo) Delete(ctx context.Context, empNo int, title, fromDate string) error {
	_, err := r.db.Exec(ctx,
		"DELETE FROM emp_title WHERE emp_no = $1 AND title = $2 AND from_date = $3",
		empNo, title, fromDate,
	)
	return err
}
