package response

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

type Body struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    any    `json:"data,omitempty"`
}

func OK(c *gin.Context, data any) {
	c.JSON(http.StatusOK, Body{Code: 0, Message: "ok", Data: data})
}

func Created(c *gin.Context, data any) {
	c.JSON(http.StatusCreated, Body{Code: 0, Message: "created", Data: data})
}

func BadRequest(c *gin.Context, msg string) {
	c.AbortWithStatusJSON(http.StatusBadRequest, Body{Code: 400, Message: msg})
}

func Unauthorized(c *gin.Context, msg string) {
	c.AbortWithStatusJSON(http.StatusUnauthorized, Body{Code: 401, Message: msg})
}

func NotFound(c *gin.Context, msg string) {
	c.AbortWithStatusJSON(http.StatusNotFound, Body{Code: 404, Message: msg})
}

func Conflict(c *gin.Context, msg string) {
	c.AbortWithStatusJSON(http.StatusConflict, Body{Code: 409, Message: msg})
}

func InternalError(c *gin.Context, msg string) {
	c.AbortWithStatusJSON(http.StatusInternalServerError, Body{Code: 500, Message: msg})
}

// Paginated wraps list results with pagination metadata
type PagedData struct {
	Items any   `json:"items"`
	Total int64 `json:"total"`
	Page  int   `json:"page"`
	Size  int   `json:"size"`
}

func OKPaged(c *gin.Context, items any, total int64, page, size int) {
	c.JSON(http.StatusOK, Body{
		Code:    0,
		Message: "ok",
		Data:    PagedData{Items: items, Total: total, Page: page, Size: size},
	})
}
