package main

import (
	"fmt"
	"log"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/emp-api/internal/config"
	"github.com/yourorg/emp-api/internal/db"
	"github.com/yourorg/emp-api/internal/handler"
	"github.com/yourorg/emp-api/internal/repository"
	"github.com/yourorg/emp-api/internal/service"
)

func main() {
	// ── Config & DB ──────────────────────────────────────────
	cfg := config.Load()
	pool := db.NewPool(cfg.DatabaseURL)
	defer pool.Close()

	gin.SetMode(cfg.GinMode)

	// ── Repositories ─────────────────────────────────────────
	empRepo   := repository.NewEmployeeRepo(pool)
	deptRepo  := repository.NewDepartmentRepo(pool)
	salRepo   := repository.NewSalaryRepo(pool)
	titleRepo := repository.NewTitleRepo(pool)

	// ── Services ─────────────────────────────────────────────
	empSvc   := service.NewEmployeeService(empRepo)
	deptSvc  := service.NewDepartmentService(deptRepo)
	salSvc   := service.NewSalaryService(salRepo)
	titleSvc := service.NewTitleService(titleRepo)

	// ── Handlers ─────────────────────────────────────────────
	empH   := handler.NewEmployeeHandler(empSvc)
	deptH  := handler.NewDepartmentHandler(deptSvc)
	salH   := handler.NewSalaryHandler(salSvc)
	titleH := handler.NewTitleHandler(titleSvc)

	// ── Router ───────────────────────────────────────────────
	engine := gin.New()
	router := handler.NewRouter(empH, deptH, salH, titleH)
	router.Setup(engine)

	addr := fmt.Sprintf(":%s", cfg.ServerPort)
	log.Printf("[server] listening on %s", addr)
	if err := engine.Run(addr); err != nil {
		log.Fatalf("[server] failed to start: %v", err)
	}
}
