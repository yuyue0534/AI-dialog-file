package repository

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/yourorg/emp-api/internal/model"
)

type EmployeeRepo struct {
	db *pgxpool.Pool
}

func NewEmployeeRepo(db *pgxpool.Pool) *EmployeeRepo {
	return &EmployeeRepo{db: db}
}

func (r *EmployeeRepo) List(ctx context.Context, page, size int, gender, name string) ([]*model.Employee, int64, error) {
	where := "WHERE 1=1"
	args := []any{}
	idx := 1

	if gender != "" {
		where += fmt.Sprintf(" AND gender = $%d", idx)
		args = append(args, gender)
		idx++
	}
	if name != "" {
		where += fmt.Sprintf(" AND (first_name ILIKE $%d OR last_name ILIKE $%d)", idx, idx+1)
		args = append(args, "%"+name+"%", "%"+name+"%")
		idx += 2
	}

	var total int64
	if err := r.db.QueryRow(ctx,
		"SELECT COUNT(*) FROM emp_employee "+where, args...,
	).Scan(&total); err != nil {
		return nil, 0, err
	}

	offset := (page - 1) * size
	query := fmt.Sprintf(
		`SELECT emp_no, birth_date, first_name, last_name, gender, hire_date
		 FROM emp_employee %s
		 ORDER BY emp_no
		 LIMIT $%d OFFSET $%d`, where, idx, idx+1,
	)
	args = append(args, size, offset)

	rows, err := r.db.Query(ctx, query, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var list []*model.Employee
	for rows.Next() {
		e := &model.Employee{}
		if err := rows.Scan(&e.EmpNo, &e.BirthDate, &e.FirstName, &e.LastName, &e.Gender, &e.HireDate); err != nil {
			return nil, 0, err
		}
		list = append(list, e)
	}
	return list, total, rows.Err()
}

func (r *EmployeeRepo) GetByID(ctx context.Context, empNo int) (*model.Employee, error) {
	e := &model.Employee{}
	err := r.db.QueryRow(ctx,
		`SELECT emp_no, birth_date, first_name, last_name, gender, hire_date
		 FROM emp_employee WHERE emp_no = $1`, empNo,
	).Scan(&e.EmpNo, &e.BirthDate, &e.FirstName, &e.LastName, &e.Gender, &e.HireDate)
	if err == pgx.ErrNoRows {
		return nil, nil
	}
	return e, err
}

func (r *EmployeeRepo) GetDetail(ctx context.Context, empNo int) (*model.EmployeeDetail, error) {
	e, err := r.GetByID(ctx, empNo)
	if err != nil || e == nil {
		return nil, err
	}
	detail := &model.EmployeeDetail{Employee: *e}

	// current department
	var deptNo, deptName string
	err = r.db.QueryRow(ctx,
		`SELECT d.dept_no, d.dept_name
		 FROM emp_dept_emp de
		 JOIN emp_department d ON d.dept_no = de.dept_no
		 WHERE de.emp_no = $1 AND de.to_date = '9999-01-01'
		 LIMIT 1`, empNo,
	).Scan(&deptNo, &deptName)
	if err == nil {
		detail.Department = &model.Department{DeptNo: deptNo, DeptName: deptName}
	}

	// current title
	var title string
	err = r.db.QueryRow(ctx,
		`SELECT title FROM emp_title
		 WHERE emp_no = $1 AND (to_date IS NULL OR to_date = '9999-01-01')
		 ORDER BY from_date DESC LIMIT 1`, empNo,
	).Scan(&title)
	if err == nil {
		detail.Title = &title
	}

	// current salary
	var amount int
	err = r.db.QueryRow(ctx,
		`SELECT amount FROM emp_salary
		 WHERE emp_no = $1 AND to_date = '9999-01-01'
		 ORDER BY from_date DESC LIMIT 1`, empNo,
	).Scan(&amount)
	if err == nil {
		detail.Salary = &amount
	}

	return detail, nil
}

func (r *EmployeeRepo) Create(ctx context.Context, e *model.Employee) (int, error) {
	var id int
	err := r.db.QueryRow(ctx,
		`INSERT INTO emp_employee (birth_date, first_name, last_name, gender, hire_date)
		 VALUES ($1,$2,$3,$4,$5) RETURNING emp_no`,
		e.BirthDate, e.FirstName, e.LastName, e.Gender, e.HireDate,
	).Scan(&id)
	return id, err
}

func (r *EmployeeRepo) Update(ctx context.Context, empNo int, fields map[string]any) error {
	if len(fields) == 0 {
		return nil
	}
	set := ""
	args := []any{}
	idx := 1
	for k, v := range fields {
		if set != "" {
			set += ", "
		}
		set += fmt.Sprintf("%s = $%d", k, idx)
		args = append(args, v)
		idx++
	}
	args = append(args, empNo)
	_, err := r.db.Exec(ctx,
		fmt.Sprintf("UPDATE emp_employee SET %s WHERE emp_no = $%d", set, idx),
		args...,
	)
	return err
}

func (r *EmployeeRepo) Delete(ctx context.Context, empNo int) error {
	_, err := r.db.Exec(ctx, "DELETE FROM emp_employee WHERE emp_no = $1", empNo)
	return err
}
