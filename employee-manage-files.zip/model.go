package model

import "time"

// ─── Employee ───────────────────────────────────────────────

type Employee struct {
	EmpNo     int       `json:"emp_no" db:"emp_no"`
	BirthDate time.Time `json:"birth_date" db:"birth_date"`
	FirstName string    `json:"first_name" db:"first_name"`
	LastName  string    `json:"last_name" db:"last_name"`
	Gender    string    `json:"gender" db:"gender"`
	HireDate  time.Time `json:"hire_date" db:"hire_date"`
}

type CreateEmployeeReq struct {
	BirthDate string `json:"birth_date" binding:"required"`
	FirstName string `json:"first_name" binding:"required"`
	LastName  string `json:"last_name" binding:"required"`
	Gender    string `json:"gender" binding:"required,oneof=M F"`
	HireDate  string `json:"hire_date" binding:"required"`
}

type UpdateEmployeeReq struct {
	BirthDate string `json:"birth_date"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	Gender    string `json:"gender" binding:"omitempty,oneof=M F"`
	HireDate  string `json:"hire_date"`
}

// ─── Department ─────────────────────────────────────────────

type Department struct {
	DeptNo   string `json:"dept_no" db:"dept_no"`
	DeptName string `json:"dept_name" db:"dept_name"`
}

type CreateDepartmentReq struct {
	DeptNo   string `json:"dept_no" binding:"required"`
	DeptName string `json:"dept_name" binding:"required"`
}

type UpdateDepartmentReq struct {
	DeptName string `json:"dept_name" binding:"required"`
}

// ─── DeptEmp (employee ↔ department assignment) ─────────────

type DeptEmp struct {
	EmpNo    int       `json:"emp_no" db:"emp_no"`
	DeptNo   string    `json:"dept_no" db:"dept_no"`
	FromDate time.Time `json:"from_date" db:"from_date"`
	ToDate   time.Time `json:"to_date" db:"to_date"`
}

type AssignDeptReq struct {
	DeptNo   string `json:"dept_no" binding:"required"`
	FromDate string `json:"from_date" binding:"required"`
	ToDate   string `json:"to_date" binding:"required"`
}

// ─── DeptManager ────────────────────────────────────────────

type DeptManager struct {
	EmpNo    int       `json:"emp_no" db:"emp_no"`
	DeptNo   string    `json:"dept_no" db:"dept_no"`
	FromDate time.Time `json:"from_date" db:"from_date"`
	ToDate   time.Time `json:"to_date" db:"to_date"`
}

type AssignManagerReq struct {
	EmpNo    int    `json:"emp_no" binding:"required"`
	FromDate string `json:"from_date" binding:"required"`
	ToDate   string `json:"to_date" binding:"required"`
}

// ─── Title ──────────────────────────────────────────────────

type Title struct {
	EmpNo    int        `json:"emp_no" db:"emp_no"`
	Title    string     `json:"title" db:"title"`
	FromDate time.Time  `json:"from_date" db:"from_date"`
	ToDate   *time.Time `json:"to_date,omitempty" db:"to_date"`
}

type AssignTitleReq struct {
	Title    string `json:"title" binding:"required"`
	FromDate string `json:"from_date" binding:"required"`
	ToDate   string `json:"to_date"`
}

// ─── Salary ─────────────────────────────────────────────────

type Salary struct {
	EmpNo    int       `json:"emp_no" db:"emp_no"`
	Amount   int       `json:"amount" db:"amount"`
	FromDate time.Time `json:"from_date" db:"from_date"`
	ToDate   time.Time `json:"to_date" db:"to_date"`
}

type CreateSalaryReq struct {
	Amount   int    `json:"amount" binding:"required,gt=0"`
	FromDate string `json:"from_date" binding:"required"`
	ToDate   string `json:"to_date" binding:"required"`
}

type UpdateSalaryReq struct {
	Amount int `json:"amount" binding:"required,gt=0"`
}

// ─── Combined view ───────────────────────────────────────────

type EmployeeDetail struct {
	Employee
	Department *Department `json:"department,omitempty"`
	Title      *string     `json:"current_title,omitempty"`
	Salary     *int        `json:"current_salary,omitempty"`
}
